import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { buildLaneSpecs, LaneSpec } from '@/lib/mockupLanes';
import {
  Copy,
  RefreshCcw,
  PlayCircle,
  SkipForward,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Eye,
  Code,
  Maximize2,
  X,
} from 'lucide-react';

export interface LaneSnapshot {
  id: string;
  title: string;
  html: string;
  diagnostics?: string[];
  url?: string | null;
  source?: 'provided' | 'generated';
}

type LaneStatus = 'pending' | 'rendering' | 'validating' | 'ready' | 'failed';

interface LaneState {
  spec: LaneSpec;
  status: LaneStatus;
  retries: number;
  logs: string[];
  html?: string;
  diagnostics?: string[];
  source?: 'provided' | 'generated';
}

interface LaneSummary {
  total: number;
  ready: number;
}

interface CritiqueResult {
  verdict: 'approved' | 'needs_revision';
  missingScreens: string[];
  redundantScreens: string[];
  journeyIssues: string[];
  suggestions: string[];
}

interface CritiqueLanePayload {
  id: string;
  title: string;
  instructions: string;
  validationHints: string[];
  html: string;
  source: 'generated' | 'provided';
  diagnostics: string[];
}

interface MockupOrchestratorProps {
  documentSource: string;
  artDirection?: string;
  planName?: string | null;
  onLanesChange?: (snapshots: LaneSnapshot[], summary: LaneSummary) => void;
}

interface ArtDirectionChange {
  previous: string;
  current: string;
}

const MAX_ATTEMPTS = 3;

const VIEWPORT_PRESETS = {
  mobile: { label: 'Mobile', width: 375 },
  tablet: { label: 'Tablet', width: 768 },
  desktop: { label: 'Desktop', width: 1280 },
  full: { label: 'Full', width: '100%' as const },
} as const;

type ViewportKey = keyof typeof VIEWPORT_PRESETS;

const VIEWPORT_STORAGE_KEY = 'ignitezero.mockup.viewport';

const slugifyMockupId = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const normalizeLaneTarget = (href: string) => {
  const sanitized = href
    .trim()
    .replace(/^(?:https?:)?\/\//, '')
    .replace(/\.html?$/i, '')
    .replace(/^\.\//, '')
    .replace(/^\/+/, '')
    .split('#')[0];
  return slugifyMockupId(sanitized || href);
};

const statusConfig: Record<
  LaneStatus,
  { label: string; badge: 'default' | 'outline' | 'secondary' | 'destructive'; tone: string }
> = {
  pending: { label: 'Pending', badge: 'outline', tone: 'text-slate-400' },
  rendering: { label: 'Rendering', badge: 'secondary', tone: 'text-cyan-300' },
  validating: { label: 'Validating', badge: 'secondary', tone: 'text-amber-300' },
  ready: { label: 'Ready', badge: 'default', tone: 'text-emerald-300' },
  failed: { label: 'Failed', badge: 'destructive', tone: 'text-rose-300' },
};

const formatTimestamp = () =>
  new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });

export function MockupOrchestrator({
  documentSource,
  artDirection,
  planName,
  onLanesChange,
}: MockupOrchestratorProps) {
  const mergedDoc = useMemo(() => {
    if (!artDirection?.trim()) return documentSource;
    return `${documentSource}\n\nMOCKUP DIRECTIVE:\n${artDirection}`;
  }, [documentSource, artDirection]);

  const [viewport, setViewport] = useState<ViewportKey>(() => {
    if (typeof window === 'undefined') return 'desktop';
    const stored = window.localStorage.getItem(VIEWPORT_STORAGE_KEY);
    return stored && stored in VIEWPORT_PRESETS ? (stored as ViewportKey) : 'desktop';
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(VIEWPORT_STORAGE_KEY, viewport);
  }, [viewport]);

  const [laneSpecs, setLaneSpecs] = useState<LaneSpec[]>([]);
  const [specsLoading, setSpecsLoading] = useState(false);
  const [artDirectionChanged, setArtDirectionChanged] = useState(false);
  const [previousArtDirection, setPreviousArtDirection] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    setSpecsLoading(true);
    buildLaneSpecs(mergedDoc, supabase.functions.invoke.bind(supabase.functions))
      .then((specs) => {
        if (isMounted) {
          setLaneSpecs(specs);
          setSpecsLoading(false);
        }
      })
      .catch((err) => {
        console.error('[MockupOrchestrator] buildLaneSpecs failed', err);
        if (isMounted) {
          setLaneSpecs([]);
          setSpecsLoading(false);
        }
      });
    return () => {
      isMounted = false;
    };
  }, [mergedDoc]);

  useEffect(() => {
    if (artDirection !== previousArtDirection && previousArtDirection !== '') {
      setArtDirectionChanged(true);
    }
    setPreviousArtDirection(artDirection || '');
  }, [artDirection, previousArtDirection]);
  const specsSignature = useMemo(
    () => laneSpecs.map((spec) => `${spec.id}:${spec.content.length}`).join('|'),
    [laneSpecs],
  );

  const [critiqueState, setCritiqueState] = useState<{
    status: 'idle' | 'loading' | 'ready' | 'error';
    data?: CritiqueResult;
    error?: string;
  }>({ status: 'idle' });
  const [lastCritiqueSignature, setLastCritiqueSignature] = useState<string | null>(null);

  const [laneStates, setLaneStates] = useState<Record<string, LaneState>>({});
  const [laneOrder, setLaneOrder] = useState<string[]>([]);
  const [activeLaneId, setActiveLaneId] = useState<string | null>(null);
  const [previewTab, setPreviewTab] = useState<'preview' | 'source'>('preview');
  const [runnerStatus, setRunnerStatus] = useState<'idle' | 'running'>('idle');
  const [fullscreenMode, setFullscreenMode] = useState(false);
  const previewIframeRef = useRef<HTMLIFrameElement | null>(null);
  const fullscreenIframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    setCritiqueState({ status: 'idle' });
    setLastCritiqueSignature(null);
  }, [specsSignature]);

  useEffect(() => {
    if (!laneSpecs.length) {
      setLaneStates({});
      setLaneOrder([]);
      setActiveLaneId(null);
      return;
    }
    const initialMap: Record<string, LaneState> = {};
    laneSpecs.forEach((spec) => {
      const hasProvided = typeof spec.providedHtml === 'string' && spec.providedHtml.trim().length > 0;
      initialMap[spec.id] = {
        spec,
        status: hasProvided ? 'ready' : 'pending',
        retries: 0,
        logs: hasProvided ? [`${formatTimestamp()} Imported provided mockup`] : [],
        html: hasProvided ? spec.providedHtml || undefined : undefined,
        source: hasProvided ? 'provided' : 'generated',
      };
    });
    setLaneStates(initialMap);
    setLaneOrder(laneSpecs.map((spec) => spec.id));
    setActiveLaneId(laneSpecs[0]?.id ?? null);
    setPreviewTab('preview');
  }, [specsSignature]);

  const updateLane = useCallback(
    (laneId: string, updater: (state: LaneState) => LaneState) => {
      setLaneStates((prev) => {
        const current = prev[laneId];
        if (!current) return prev;
        return { ...prev, [laneId]: updater(current) };
      });
    },
    [],
  );

  const appendLog = useCallback(
    (laneId: string, message: string) => {
      updateLane(laneId, (lane) => ({
        ...lane,
        logs: [...lane.logs, `${formatTimestamp()} ${message}`].slice(-10),
      }));
    },
    [updateLane],
  );

  const laneList = useMemo(() => laneOrder.map((id) => ({ id, state: laneStates[id] })), [laneOrder, laneStates]);

  const laneSlugMap = useMemo(() => {
    const map: Record<string, string> = {};
    laneOrder.forEach((id) => {
      const spec = laneStates[id]?.spec;
      if (!spec) return;
      const slugCandidates = new Set<string>();
      if (spec.id) {
        slugCandidates.add(spec.id.toLowerCase());
        slugCandidates.add(slugifyMockupId(spec.id));
      }
      if (spec.title) {
        slugCandidates.add(spec.title.toLowerCase());
        slugCandidates.add(slugifyMockupId(spec.title));
      }
      slugCandidates.forEach((slug) => {
        if (slug) {
          map[slug] = id;
        }
      });
    });
    return map;
  }, [laneOrder, laneStates]);

  const attachLinkHijacker = useCallback(
    (iframe: HTMLIFrameElement | null) => {
      if (!iframe) return;
      const doc = iframe.contentDocument;
      if (!doc) return;
      const anchors = Array.from(doc.querySelectorAll<HTMLAnchorElement>('a[href]'));
      anchors.forEach((anchor) => {
        const rawHref = anchor.getAttribute('href');
        if (!rawHref) return;
        if (/^(?:https?:|mailto:|tel:)/i.test(rawHref)) return;
        if (anchor.dataset.mockupHijacked === 'true') return;
        const targetSlug = normalizeLaneTarget(rawHref);
        const targetLaneId = laneSlugMap[targetSlug];
        if (!targetLaneId) return;
        anchor.dataset.mockupHijacked = 'true';
        anchor.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          if (targetLaneId === activeLaneId) return;
          setActiveLaneId(targetLaneId);
          setPreviewTab('preview');
        });
      });
    },
    [activeLaneId, laneSlugMap, setPreviewTab],
  );

  const readySnapshots: LaneSnapshot[] = useMemo(
    () =>
      laneList
        .filter(({ state }) => state?.status === 'ready' && state.html)
        .map(({ id, state }) => ({
          id,
          title: state?.spec.title ?? id,
          html: state?.html ?? '',
          diagnostics: state?.diagnostics,
          source:
            state?.source ??
            (state?.spec.providedHtml ? 'provided' : 'generated'),
        })),
    [laneList],
  );

  useEffect(() => {
    onLanesChange?.(readySnapshots, {
      total: laneOrder.length,
      ready: readySnapshots.length,
    });
  }, [laneOrder.length, onLanesChange, readySnapshots]);

  const progressPct = laneOrder.length
    ? Math.round((readySnapshots.length / laneOrder.length) * 100)
    : 0;

  const activeLane = activeLaneId ? laneStates[activeLaneId] : undefined;
  const previewViewportStyle = useMemo(() => {
    const preset = VIEWPORT_PRESETS[viewport];
    if (!preset) return { width: '100%', maxWidth: '100%' };
    if (preset.width === '100%') {
      return { width: '100%', maxWidth: '100%' };
    }
    return { width: `${preset.width}px`, maxWidth: '100%' };
  }, [viewport]);
  const activeLaneHtml = activeLane?.html ?? '';

  const renderCritiqueList = (title: string, items: string[]) => {
    if (!items.length) return null;
    return (
      <div className="space-y-1">
        <p className="text-[11px] uppercase tracking-wider text-slate-500">{title}</p>
        <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
          {items.map((item) => (
            <li key={`${title}-${item}`}>{item}</li>
          ))}
        </ul>
      </div>
    );
  };

  const renderViewportButtons = (wrapperClass?: string) => (
    <div className={`flex items-center gap-2 ${wrapperClass ?? ''}`}>
      {Object.entries(VIEWPORT_PRESETS).map(([key, preset]) => {
        const isActive = viewport === key;
        return (
          <button
            key={key}
            type="button"
            onClick={() => setViewport(key as ViewportKey)}
            className={`rounded border px-2 py-1 text-[11px] font-medium transition ${
              isActive
                ? 'border-emerald-400/40 bg-emerald-400/10 text-emerald-300'
                : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700'
            }`}
          >
            {preset.label}
          </button>
        );
      })}
    </div>
  );

  const verdictBadgeClass =
    critiqueState.data?.verdict === 'approved'
      ? 'border-emerald-400/40 text-emerald-300 bg-emerald-400/10'
      : 'border-amber-400/40 text-amber-300 bg-amber-500/10';

  useEffect(() => {
    if (previewTab !== 'preview') return;
    const iframe = previewIframeRef.current;
    if (!iframe) return;
    const handleLoad = () => attachLinkHijacker(iframe);
    iframe.addEventListener('load', handleLoad);
    if (iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
      attachLinkHijacker(iframe);
    }
    return () => {
      iframe.removeEventListener('load', handleLoad);
    };
  }, [attachLinkHijacker, activeLaneHtml, previewTab, viewport]);

  useEffect(() => {
    if (!fullscreenMode) return;
    const iframe = fullscreenIframeRef.current;
    if (!iframe) return;
    const handleLoad = () => attachLinkHijacker(iframe);
    iframe.addEventListener('load', handleLoad);
    if (iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
      attachLinkHijacker(iframe);
    }
    return () => {
      iframe.removeEventListener('load', handleLoad);
    };
  }, [attachLinkHijacker, activeLaneHtml, fullscreenMode, viewport]);

  const critiqueSignature = useMemo(
    () =>
      readySnapshots
        .map((snapshot) => `${snapshot.id}:${snapshot.html.length}:${snapshot.source ?? 'generated'}`)
        .join('|'),
    [readySnapshots],
  );

  const fetchCritique = useCallback(
    async (signature: string) => {
      const lanePayload: CritiqueLanePayload[] = laneOrder
        .map((id) => {
          const lane = laneStates[id];
          if (!lane) return null;
          const rawHtml = lane.html ?? lane.spec.providedHtml ?? '';
          return {
            id,
            title: lane.spec.title,
            instructions: lane.spec.instructions,
            validationHints: lane.spec.validationHints,
            html: typeof rawHtml === 'string' ? rawHtml.slice(0, 15000) : '',
            source: lane.source ?? (lane.spec.providedHtml ? 'provided' : 'generated'),
            diagnostics: lane.diagnostics ?? [],
          };
        })
        .filter((lane): lane is CritiqueLanePayload => lane !== null);

      if (!lanePayload.length) return;

      setCritiqueState({ status: 'loading' });
      try {
        const { data, error } = await supabase.functions.invoke('architect-advisor', {
          body: {
            mode: 'mockup-critique',
            prompt: mergedDoc,
            context: {
              artDirection: artDirection ?? '',
              planName: planName ?? null,
            },
            lanes: lanePayload,
          },
        });

        if (error) {
          throw new Error(error.message);
        }

        const raw = typeof data?.result === 'string' ? JSON.parse(data.result) : data?.result;
        const sanitizeList = (value: unknown) =>
          Array.isArray(value) ? value.map((item) => String(item).trim()).filter(Boolean).slice(0, 5) : [];

        const normalized: CritiqueResult = {
          verdict: raw?.verdict === 'approved' ? 'approved' : 'needs_revision',
          missingScreens: sanitizeList(raw?.missing_screens),
          redundantScreens: sanitizeList(raw?.redundant_screens),
          journeyIssues: sanitizeList(raw?.journey_issues),
          suggestions: sanitizeList(raw?.suggestions),
        };

        if (
          normalized.verdict === 'approved' &&
          (normalized.missingScreens.length > 0 || normalized.journeyIssues.length > 0)
        ) {
          normalized.verdict = 'needs_revision';
        }

        setCritiqueState({ status: 'ready', data: normalized });
        setLastCritiqueSignature(signature);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error('[MockupOrchestrator] mockup-critique failed', err);
        setCritiqueState({ status: 'error', error: message });
      }
    },
    [artDirection, laneOrder, laneStates, mergedDoc, planName],
  );

  useEffect(() => {
    if (!laneOrder.length || readySnapshots.length === 0) {
      if (critiqueState.status !== 'idle') {
        setCritiqueState({ status: 'idle' });
      }
      return;
    }
    if (readySnapshots.length !== laneOrder.length) return;
    if (runnerStatus === 'running') return;
    if (!critiqueSignature || critiqueSignature === lastCritiqueSignature) return;
    fetchCritique(critiqueSignature);
  }, [
    critiqueSignature,
    critiqueState.status,
    fetchCritique,
    laneOrder.length,
    lastCritiqueSignature,
    readySnapshots.length,
    runnerStatus,
  ]);

  const parseLaneResponse = (payload: any) => {
    if (!payload) return null;
    if (typeof payload === 'string') {
      try {
        return JSON.parse(payload);
      } catch (err) {
        return null;
      }
    }
    return payload;
  };

  const runLane = useCallback(
    async (laneId: string, attempt = 0): Promise<void> => {
      const lane = laneStates[laneId];
      if (!lane) return;

      updateLane(laneId, (current) => ({
        ...current,
        status: 'rendering',
        retries: attempt,
      }));
      appendLog(laneId, `Attempt ${attempt + 1} started`);

      const { data, error } = await supabase.functions.invoke('architect-advisor', {
        body: {
          mode: 'mockup-lane',
          prompt: lane.spec.content,
          laneId,
          pageSpec: lane.spec.content,
          validationHints: lane.spec.validationHints,
          otherLanes: laneOrder
            .filter((id) => id !== laneId)
            .map((id) => ({ id, title: laneStates[id]?.spec.title || id })),
        },
      });

      if (error) {
        appendLog(laneId, `Error: ${error.message}`);
        updateLane(laneId, (current) => ({
          ...current,
          status: 'failed',
        }));
        toast.error(`Lane ${lane.spec.title} failed: ${error.message}`);
        return;
      }

      updateLane(laneId, (current) => ({
        ...current,
        status: 'validating',
      }));

      const parsed = parseLaneResponse(data?.result);
      if (!parsed) {
        appendLog(laneId, 'Invalid response from architect-advisor');
        updateLane(laneId, (current) => ({
          ...current,
          status: 'failed',
        }));
        toast.error(`Lane ${lane.spec.title} failed: invalid response`);
        return;
      }

      if (parsed.status === 'needs_revision') {
        if (typeof parsed.html === 'string') {
          updateLane(laneId, (current) => ({
            ...current,
            html: parsed.html,
            diagnostics: parsed.diagnostics,
          }));
        }
        appendLog(
          laneId,
          `Validator flagged missing sections: ${(parsed.diagnostics || []).join(', ') || 'unspecified'}`,
        );
        if (attempt + 1 >= MAX_ATTEMPTS) {
          updateLane(laneId, (current) => ({
            ...current,
            status: 'failed',
            diagnostics: parsed.diagnostics,
          }));
          toast.error(`Lane ${lane.spec.title} failed after ${MAX_ATTEMPTS} attempts.`);
          return;
        }
        await runLane(laneId, attempt + 1);
        return;
      }

      updateLane(laneId, (current) => ({
        ...current,
        status: 'ready',
        html: parsed.html,
        diagnostics: parsed.diagnostics,
        source: current.source ?? 'generated',
      }));
      appendLog(laneId, 'Lane ready');
      toast.success(`${lane.spec.title} mockup ready`);
    },
    [appendLog, laneStates, updateLane],
  );

  const runAllLanes = useCallback(async () => {
    if (!laneOrder.length) {
      toast.error('No lanes detected in the document.');
      return;
    }
    if (runnerStatus === 'running') return;
    setRunnerStatus('running');
    setArtDirectionChanged(false);
    for (const laneId of laneOrder) {
      const lane = laneStates[laneId];
      if (!lane || lane.status === 'ready') continue;
      await runLane(laneId);
    }
    setRunnerStatus('idle');
  }, [laneOrder, laneStates, runLane, runnerStatus]);

  const regenerateAllLanes = useCallback(async () => {
    if (!laneOrder.length) {
      toast.error('No lanes to regenerate.');
      return;
    }
    if (runnerStatus === 'running') return;
    setRunnerStatus('running');
    setArtDirectionChanged(false);
    
    laneOrder.forEach((laneId) => {
      updateLane(laneId, (current) => ({
        ...current,
        status: current.source === 'provided' ? 'ready' : 'pending',
        html: current.source === 'provided' ? current.html : undefined,
      }));
    });

    for (const laneId of laneOrder) {
      const lane = laneStates[laneId];
      if (!lane || lane.source === 'provided') continue;
      await runLane(laneId);
    }
    setRunnerStatus('idle');
    toast.success('Mockups regenerated with new art direction.');
  }, [laneOrder, laneStates, runLane, runnerStatus, updateLane]);

  const resumePending = useCallback(async () => {
    if (runnerStatus === 'running') return;
    const remaining = laneOrder.filter((id) => laneStates[id]?.status !== 'ready');
    if (!remaining.length) {
      toast.message('All lanes already ready.');
      return;
    }
    setRunnerStatus('running');
    for (const laneId of remaining) {
      await runLane(laneId);
    }
    setRunnerStatus('idle');
  }, [laneOrder, laneStates, runLane, runnerStatus]);

  const copyActiveHtml = useCallback(async () => {
    if (!activeLane?.html) {
      toast.error('Generate a lane before copying.');
      return;
    }
    await navigator.clipboard.writeText(activeLane.html);
    toast.success('HTML copied to clipboard');
  }, [activeLane]);

  const downloadActiveHtml = useCallback(() => {
    if (!activeLane?.html) {
      toast.error('Generate a lane before downloading.');
      return;
    }
    const blob = new Blob([activeLane.html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${planName || 'mockup'}-${activeLane.spec.id}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [activeLane, planName]);

  const hasPending = laneOrder.some((id) => laneStates[id]?.status !== 'ready');

  if (specsLoading) {
    return (
      <Card className="border-slate-800 bg-slate-950">
        <CardContent className="py-12 flex flex-col items-center justify-center gap-4">
          <Loader2 className="h-8 w-8 text-emerald-400 animate-spin" />
          <p className="text-sm text-slate-400">Analyzing document structure...</p>
        </CardContent>
      </Card>
    );
  }

  if (fullscreenMode) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950 flex">
        <div className="w-80 border-r border-slate-800 bg-slate-900 flex flex-col">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Mockup Gallery</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setFullscreenMode(false)}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-3 space-y-2">
              {laneList.map(({ id, state }) => {
                if (!state) return null;
                const config = statusConfig[state.status];
                return (
                  <button
                    key={id}
                    onClick={() => {
                      setActiveLaneId(id);
                      setPreviewTab('preview');
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-left transition ${
                      activeLaneId === id
                        ? 'border-emerald-400 bg-emerald-400/10'
                        : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                    }`}
                  >
                    <p className="text-sm font-semibold text-slate-100">{state.spec.title}</p>
                    <Badge variant={config.badge} className="text-[10px] mt-1">
                      {config.label}
                    </Badge>
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </div>
        <div className="flex-1 flex flex-col">
          <div className="p-4 border-b border-slate-800 bg-slate-900/50 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                {activeLane?.spec.title ?? 'Select a lane'}
              </Badge>
              {activeLane?.status && (
                <span className={`text-xs ${statusConfig[activeLane.status].tone}`}>
                  {statusConfig[activeLane.status].label}
                </span>
              )}
            </div>
            {renderViewportButtons()}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyActiveHtml} disabled={!activeLane?.html}>
                <Copy className="h-3.5 w-3.5 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadActiveHtml} disabled={!activeLane?.html}>
                <RefreshCcw className="h-3.5 w-3.5 mr-2" />
                Download
              </Button>
            </div>
          </div>
          <div className="flex-1 bg-slate-950 p-4 overflow-auto">
            {activeLane?.html ? (
              <div className="w-full flex justify-center">
                <div className="w-full" style={previewViewportStyle}>
                  <iframe
                    ref={fullscreenIframeRef}
                    title="Fullscreen preview"
                    srcDoc={activeLane.html}
                    sandbox="allow-same-origin"
                    className="w-full min-h-[600px] rounded-lg bg-white shadow-lg"
                  />
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-500">
                Select a lane to preview
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <Card className="border-slate-800 bg-slate-950">
      <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <CardTitle className="text-emerald-300 font-mono text-lg">Blueprint Mockup Orchestrator</CardTitle>
          <p className="text-sm text-slate-400">
            Generates pixel-perfect HTML for each core experience.
          </p>
          <div className="mt-2 w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all duration-500"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-xs text-slate-500">
            {readySnapshots.length} / {laneOrder.length || 0} lanes ready
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {artDirectionChanged && (
            <Button
              onClick={regenerateAllLanes}
              disabled={runnerStatus === 'running'}
              className="min-w-[200px] bg-amber-600 hover:bg-amber-500"
            >
              {runnerStatus === 'running' ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Regenerating...
                </>
              ) : (
                <>
                  <RefreshCcw className="h-4 w-4 mr-2" />
                  Apply New Art Direction
                </>
              )}
            </Button>
          )}
          <Button
            onClick={runAllLanes}
            disabled={runnerStatus === 'running' || !laneOrder.length}
            className="min-w-[180px]"
          >
            {runnerStatus === 'running' ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Rendering...
              </>
            ) : (
              <>
                <PlayCircle className="h-4 w-4 mr-2" />
                Generate Blueprints
              </>
            )}
          </Button>
          <Button
            variant="outline"
            onClick={resumePending}
            disabled={runnerStatus === 'running' || !hasPending}
          >
            <SkipForward className="h-4 w-4 mr-2" />
            Resume Pending
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-6 lg:grid-cols-[280px,1fr]">
          <div className="space-y-3">
            <ScrollArea className="h-[420px] rounded-lg border border-slate-800">
              <div className="p-3 space-y-3">
                {laneList.map(({ id, state }) => {
                  if (!state) return null;
                  const config = statusConfig[state.status];
                  return (
                    <button
                      key={id}
                      onClick={() => {
                        setActiveLaneId(id);
                        setPreviewTab('preview');
                      }}
                      className={`w-full rounded-lg border px-3 py-3 text-left transition ${
                        activeLaneId === id
                          ? 'border-emerald-400 bg-emerald-400/10'
                          : 'border-slate-800 bg-slate-900 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                            {state.spec.title}
                            {state.spec.providedHtml && (
                              <span className="text-[10px] font-mono text-cyan-300 uppercase">
                                Provided
                              </span>
                            )}
                          </p>
                          <p className="text-xs text-slate-500">{state.spec.instructions}</p>
                        </div>
                        <Badge variant={config.badge} className="text-[10px] uppercase tracking-wide">
                          {config.label}
                        </Badge>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {state.spec.validationHints.map((hint) => (
                          <span
                            key={hint}
                            className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400"
                          >
                            {hint}
                          </span>
                        ))}
                      </div>
                      {state.status === 'failed' && (
                        <div className="mt-2 text-xs text-rose-300 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          Needs attention
                        </div>
                      )}
                      {state.status === 'ready' && (
                        <div className="mt-2 text-xs text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          {state.retries > 0 ? `Ready after ${state.retries + 1} attempts` : 'Ready'}
                        </div>
                      )}
                    </button>
                  );
                })}
                {!laneList.length && (
                  <p className="text-sm text-slate-500 text-center py-12">
                    Paste your specification to begin generating mockups.
                  </p>
                )}
              </div>
            </ScrollArea>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Badge variant="outline" className="text-[10px]">
                  {activeLane?.spec.title ?? 'Select a lane'}
                </Badge>
                {activeLane?.status && (
                  <span className={statusConfig[activeLane.status].tone}>
                    {statusConfig[activeLane.status].label}
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setFullscreenMode(true)} 
                  disabled={!activeLane?.html}
                >
                  <Maximize2 className="h-3.5 w-3.5 mr-2" />
                  Fullscreen
                </Button>
                <Button variant="outline" size="sm" onClick={copyActiveHtml} disabled={!activeLane?.html}>
                  <Copy className="h-3.5 w-3.5 mr-2" />
                  Copy HTML
                </Button>
                <Button variant="outline" size="sm" onClick={downloadActiveHtml} disabled={!activeLane?.html}>
                  <RefreshCcw className="h-3.5 w-3.5 mr-2" />
                  Download
                </Button>
              </div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-3">
                <div className="flex">
                  <button
                    className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold ${
                      previewTab === 'preview'
                        ? 'text-white border-b-2 border-emerald-400'
                        : 'text-slate-500'
                    }`}
                    onClick={() => setPreviewTab('preview')}
                  >
                    <Eye className="h-3.5 w-3.5" />
                    Preview
                  </button>
                  <button
                    className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold ${
                      previewTab === 'source'
                        ? 'text-white border-b-2 border-emerald-400'
                        : 'text-slate-500'
                    }`}
                    onClick={() => setPreviewTab('source')}
                  >
                    <Code className="h-3.5 w-3.5" />
                    HTML
                  </button>
                </div>
                {renderViewportButtons('py-2')}
              </div>
              <div className="min-h-[360px] bg-slate-950 flex items-center justify-center p-4">
                {previewTab === 'preview' ? (
                  activeLane?.html ? (
                    <div className="w-full h-full overflow-auto">
                      <div className="mx-auto" style={previewViewportStyle}>
                        <iframe
                          ref={previewIframeRef}
                          title="Lane preview"
                          srcDoc={activeLane.html}
                          sandbox="allow-same-origin"
                          className="w-full min-h-[360px] rounded-lg bg-white shadow"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="text-sm text-slate-500 text-center space-y-2">
                      <p>Select a lane and run the generator to view the HTML.</p>
                    </div>
                  )
                ) : (
                  <ScrollArea className="w-full h-[360px] rounded-lg border border-slate-800 bg-slate-950">
                    <pre className="p-4 text-[11px] text-slate-200 whitespace-pre-wrap">
                      {activeLane?.html ?? 'Generate a lane to inspect the HTML source.'}
                    </pre>
                  </ScrollArea>
                )}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800 p-4 bg-slate-900/60 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                  Product Critic
                </p>
                {critiqueState.status === 'loading' && (
                  <Loader2 className="h-4 w-4 animate-spin text-emerald-300" />
                )}
                {critiqueState.status === 'ready' && critiqueState.data && (
                  <Badge variant="outline" className={`text-[11px] ${verdictBadgeClass}`}>
                    {critiqueState.data.verdict === 'approved' ? 'Approved' : 'Needs Revision'}
                  </Badge>
                )}
              </div>
              {critiqueState.status === 'idle' && (
                <p className="text-xs text-slate-500">
                  Generate all lanes to get an automated product review.
                </p>
              )}
              {critiqueState.status === 'error' && (
                <p className="text-xs text-rose-300">
                  Critique failed: {critiqueState.error ?? 'Unknown error'}
                </p>
              )}
              {critiqueState.status === 'ready' && critiqueState.data && (
                <div className="space-y-3">
                  {renderCritiqueList('Missing Screens', critiqueState.data.missingScreens)}
                  {renderCritiqueList('Redundant Screens', critiqueState.data.redundantScreens)}
                  {renderCritiqueList('Journey Issues', critiqueState.data.journeyIssues)}
                  {renderCritiqueList('Suggestions', critiqueState.data.suggestions)}
                  {!critiqueState.data.missingScreens.length &&
                    !critiqueState.data.redundantScreens.length &&
                    !critiqueState.data.journeyIssues.length &&
                    !critiqueState.data.suggestions.length && (
                      <p className="text-xs text-slate-400">
                        No findings. This flow matches the current brief.
                      </p>
                    )}
                </div>
              )}
            </div>
            <div className="rounded-lg border border-slate-800 p-4 bg-slate-900/60">
              <p className="text-xs font-semibold text-slate-400 mb-2">Activity Log</p>
              <ScrollArea className="h-24">
                <div className="space-y-1 text-xs text-slate-400">
                  {activeLane?.logs?.length
                    ? activeLane.logs.map((entry, idx) => <p key={idx}>{entry}</p>)
                    : 'No activity yet.'}
                </div>
              </ScrollArea>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default MockupOrchestrator;


