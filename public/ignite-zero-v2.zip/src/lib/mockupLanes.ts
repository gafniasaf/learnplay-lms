import { extractHtmlSnippet, extractAllHtmlSnippets, extractPageTitle } from '@/lib/htmlUtils';

export interface LaneTemplate {
  id: string;
  title: string;
  keywords: string[];
  instructions: string;
  validationHints: string[];
}

export interface LaneSpec extends LaneTemplate {
  content: string;
  providedHtml?: string | null;
}

interface SectionClassification {
  heading: string;
  type: 'ui_page' | 'documentation';
  reason: string;
  validationHints?: string[];
}

const FALLBACK_TEMPLATES: LaneTemplate[] = [
  {
    id: 'home',
    title: 'Public Home',
    keywords: ['Public & Authentication', 'Home Page', 'Landing'],
    instructions:
      'Render the marketing landing page with hero, portal grid, CTA buttons, and global header/footer.',
    validationHints: ['Hero Section', 'Portal Grid', 'CTA Buttons', 'Header + Footer'],
  },
  {
    id: 'auth',
    title: 'Authentication',
    keywords: ['Authentication Page', 'Reset Password', 'Login', 'Sign Up'],
    instructions:
      'Design the login/sign-up experience with tabs, inputs, social auth, and forgot password modal.',
    validationHints: ['Login Tab', 'Sign Up Tab', 'Social Buttons', 'Forgot Password'],
  },
  {
    id: 'dashboard',
    title: 'Main Dashboard',
    keywords: ['Dashboard', 'Overview', 'Main Screen'],
    instructions:
      'Build the main dashboard with summary cards, navigation, and key metrics.',
    validationHints: ['Summary Cards', 'Navigation', 'Key Metrics'],
  },
  {
    id: 'admin',
    title: 'Admin Panel',
    keywords: ['Admin', 'Management', 'Settings'],
    instructions:
      'Mock the admin workspace with sidebar, data tables, and management controls.',
    validationHints: ['Sidebar', 'Data Table', 'Controls'],
  },
];

interface ParsedSection {
  heading: string;
  body: string;
}

function extractSections(doc: string): ParsedSection[] {
  const sections: ParsedSection[] = [];
  const lines = doc.split(/\r?\n/);
  let currentHeading = '';
  let currentBody: string[] = [];

  const flush = () => {
    if (!currentHeading) return;
    sections.push({
      heading: currentHeading.trim(),
      body: currentBody.join('\n').trim(),
    });
    currentBody = [];
  };

  lines.forEach((line) => {
    if (line.trim().match(/^#{2,4}\s+/)) {
      flush();
      currentHeading = line.trim();
    } else {
      currentBody.push(line);
    }
  });
  flush();

  return sections;
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/^#{2,4}\s+/, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50) || 'page';
}

function extractValidationHints(html: string): string[] {
  const hints: string[] = [];
  const headerMatch = html.match(/<header[^>]*>/i);
  const footerMatch = html.match(/<footer[^>]*>/i);
  const navMatch = html.match(/<nav[^>]*>/i);
  const formMatch = html.match(/<form[^>]*>/i);
  const tableMatch = html.match(/<table[^>]*>/i);

  if (headerMatch) hints.push('Header');
  if (footerMatch) hints.push('Footer');
  if (navMatch) hints.push('Navigation');
  if (formMatch) hints.push('Form');
  if (tableMatch) hints.push('Table');

  if (hints.length === 0) hints.push('Main Content');

  return hints;
}

function withRequiredElements(base: string, hints: string[]): string {
  if (!hints.length) return base.trim();
  const checklist = hints.map((hint, idx) => `${idx + 1}. ${hint}`).join('\n');
  return `${base.trim()}\n\nREQUIRED ELEMENTS:\n${checklist}`.trim();
}

export async function classifySections(
  sections: ParsedSection[],
  supabaseInvoke: (name: string, opts: any) => Promise<any>,
): Promise<SectionClassification[]> {
  if (sections.length === 0) return [];

  try {
    const { data, error } = await supabaseInvoke('architect-advisor', {
      body: {
        mode: 'analyze-document',
        prompt: 'Classify document sections',
        sections: sections.map((s) => ({
          heading: s.heading,
          preview: s.body.slice(0, 300),
        })),
      },
    });

    if (error) {
      console.warn('[classifySections] LLM call failed, falling back to all sections', error);
      return sections.map((s) => ({
        heading: s.heading,
        type: 'ui_page' as const,
        reason: 'Fallback: LLM unavailable',
      }));
    }

    const parsed = typeof data?.result === 'string' ? JSON.parse(data.result) : data?.result;
    const classifications = Array.isArray(parsed?.sections) ? parsed.sections : [];
    return classifications;
  } catch (err) {
    console.warn('[classifySections] Exception, falling back', err);
    return sections.map((s) => ({
      heading: s.heading,
      type: 'ui_page' as const,
      reason: 'Fallback: Exception',
    }));
  }
}

async function inferLanesFromDocument(
  sections: ParsedSection[],
  supabaseInvoke: (name: string, opts: any) => Promise<any>,
): Promise<LaneSpec[]> {
  const classifications = await classifySections(sections, supabaseInvoke);
  const classificationMap = new Map(classifications.map(c => [c.heading, c]));

  const lanes: LaneSpec[] = [];

  sections.forEach((section) => {
    const cleanHeading = section.heading.replace(/^#{2,4}\s+/, '').trim();
    const classification = classificationMap.get(section.heading);
    const isUiPage = classification?.type === 'ui_page';

    if (!isUiPage) return;

    const html = extractHtmlSnippet(section.body);
    const id = slugify(section.heading);
    const title = cleanHeading;

    const validationHints = classification?.validationHints?.length
      ? classification.validationHints
      : (html ? extractValidationHints(html) : []);

    lanes.push({
      id,
      title,
      keywords: [title],
      instructions: html
        ? `Render ${title} exactly as provided in the document.`
        : `Generate ${title} based on the document context.`,
      validationHints,
      content: withRequiredElements(`${section.heading}\n${section.body}`, validationHints),
      providedHtml: html || undefined,
    });
  });

  return lanes;
}

function inferLanesFromRawHtml(doc: string): LaneSpec[] {
  const allHtml = extractAllHtmlSnippets(doc);
  if (allHtml.length === 0) return [];

  return allHtml.map((html, idx) => {
    const title = extractPageTitle(html) || `Page ${idx + 1}`;
    const id = slugify(title);
    const validationHints = extractValidationHints(html);

    return {
      id,
      title,
      keywords: [title],
      instructions: `Render ${title} exactly as provided in the document.`,
      validationHints,
      content: withRequiredElements(html, validationHints),
      providedHtml: html,
    };
  });
}

export async function buildLaneSpecs(
  doc: string,
  supabaseInvoke?: (name: string, opts: any) => Promise<any>,
): Promise<LaneSpec[]> {
  const sections = extractSections(doc);

  if (sections.length > 0 && supabaseInvoke) {
    const inferred = await inferLanesFromDocument(sections, supabaseInvoke);
    return inferred;
  }

  if (sections.length > 0) {
    const lanes: LaneSpec[] = [];
    sections.forEach((section) => {
      const html = extractHtmlSnippet(section.body);
      const id = slugify(section.heading);
      const title = section.heading.replace(/^#{2,4}\s+/, '').trim();
      const validationHints = html
        ? extractValidationHints(html)
        : [];

      lanes.push({
        id,
        title,
        keywords: [title],
        instructions: html
          ? `Render ${title} exactly as provided in the document.`
          : `Generate ${title} based on the document context.`,
        validationHints,
        content: withRequiredElements(`${section.heading}\n${section.body}`, validationHints),
        providedHtml: html || undefined,
      });
    });
    if (lanes.length > 0) return lanes;
  }

  const rawHtmlLanes = inferLanesFromRawHtml(doc);
  if (rawHtmlLanes.length > 0) {
    return rawHtmlLanes;
  }

  const fallback = doc.trim();
  return FALLBACK_TEMPLATES.map((template) => {
    const matchedSection = sections.find(({ heading, body }) => {
      const needle = template.keywords.map((k) => k.toLowerCase());
      const haystack = `${heading} ${body}`.toLowerCase();
      return needle.some((n) => haystack.includes(n));
    });

    const baseContent = matchedSection
      ? `${matchedSection.heading}\n${matchedSection.body}`.trim()
      : fallback;

    return {
      ...template,
      content: withRequiredElements(baseContent, template.validationHints),
      providedHtml: undefined,
    };
  });
}

export { FALLBACK_TEMPLATES as LANE_TEMPLATES };
