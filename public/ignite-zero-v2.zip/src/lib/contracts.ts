
// ------------------------------------------------------------------
// ⚠️ AUTO-GENERATED FROM system-manifest.json
// ------------------------------------------------------------------
import { z } from 'zod';


export const ProjectBoardSchema = z.object({
  id: z.string().uuid(),
  organization_id: z.string().uuid(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
  version: z.number().int().default(1),
  format: z.string().default('v1'),
  name: z.string(),
  description: z.string().optional(),
  status: z.string().optional(),
  tasks: z.any().optional().describe("Array of TaskItem")
});
export type ProjectBoard = z.infer<typeof ProjectBoardSchema>;


export const TaskItemSchema = z.object({
  id: z.string().uuid(),
  organization_id: z.string().uuid(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
  version: z.number().int().default(1),
  format: z.string().default('v1'),
  title: z.string(),
  status: z.string().optional().describe("todo | doing | done"),
  assignee: z.string().optional()
});
export type TaskItem = z.infer<typeof TaskItemSchema>;


// --- Agent Job Contracts (Strict) ---

export const JobPayloadSchema = z.discriminatedUnion('jobType', [

  z.object({
    jobType: z.literal('generate_subtasks'),
    projectId: z.string().uuid(), 
    payload: z.record(z.any()).optional().describe("Input for expand_task")
  })
]);
export type JobPayload = z.infer<typeof JobPayloadSchema>;


// --- Entity Field Definitions (for Smart Inputs) ---
export const ENTITY_FIELDS = {
  "ProjectBoard": [
    {
      "key": "name",
      "type": "string",
      "required": true
    },
    {
      "key": "description",
      "type": "string"
    },
    {
      "key": "status",
      "type": "string"
    },
    {
      "key": "tasks",
      "type": "json",
      "description": "Array of TaskItem"
    }
  ],
  "TaskItem": [
    {
      "key": "title",
      "type": "string",
      "required": true
    },
    {
      "key": "status",
      "type": "string",
      "description": "todo | doing | done"
    },
    {
      "key": "assignee",
      "type": "string"
    }
  ]
} as const;
