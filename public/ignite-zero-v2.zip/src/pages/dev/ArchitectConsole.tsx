import { useMemo, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Copy, Check } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { JobWatchtower } from '@/components/dev/JobWatchtower';
import { ConsultLogWatchtower } from '@/components/dev/ConsultLogWatchtower';
import { SystemGenesisV2 as SystemGenesis } from '@/components/dev/SystemGenesis';
import manifest from '../../../system-manifest.json';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';
import { FactoryGuide } from '@/components/dev/FactoryGuide';
import { BuilderShell } from '@/components/dev/BuilderShell';
import { BlueprintVisualizer } from '@/components/dev/BlueprintVisualizer';
import { useAuth } from '@/hooks/useAuth';
import { ensureSessionSlug } from '@/lib/session';

export default function ArchitectConsole() {
  // Evolution State
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('Awaiting instructions...');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [resumeLoading, setResumeLoading] = useState(false);
  const { user } = useAuth();
  const sessionSlug = useMemo(() => ensureSessionSlug(), []);

  const runEvolution = async () => {
    if (!prompt) return;
    setLoading(true);
    setResponse('Processing request...');
    setCopied(false);
    
    try {
      const { data, error } = await supabase.functions.invoke('architect-advisor', {
        body: {
          prompt,
          mode: 'evolution',
          manifest,
          ownerId: user?.id,
          sessionId: sessionSlug,
        },
      });
      if (error) {
        setResponse(`**Error:** ${error.message}\n\n**Details:** ${JSON.stringify(error, null, 2)}`);
      } else {
        setResponse(data?.result || 'No response');
      }
    } catch (err: any) {
      setResponse(`**Exception:** ${err?.message || String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  const copyOutput = async () => {
    try {
      await navigator.clipboard.writeText(response);
      setCopied(true);
      toast.success('Plan copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error('Failed to copy');
    }
  };

  const handleResumeSession = async () => {
    setResumeLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('resume-session', {
        body: {
          projectName: manifest.system?.name,
          ownerId: user?.id,
          sessionId: sessionSlug,
        },
      });

      if (error) {
        throw error;
      }

      if (!data?.plan) {
        toast.error('No saved sessions found yet.');
        return;
      }

      const planData = data.plan;
      const planJson = planData.plan ?? {};
      const markdown =
        planData.markdown_plan ??
        planJson?.markdown_plan ??
        JSON.stringify(planJson, null, 2);
      const summary =
        planData.summary ??
        planJson?.analysis?.summary ??
        'No summary captured.';

      const consultNote = data.consult?.response ?? 'No consultant log yet.';
      const mockupNote = data.mockup
        ? `Latest Mockup (${(data.mockup.source || 'ai').toUpperCase()}): ${data.mockup.url}`
        : 'No stored mockup yet. Generate a new one in the Genesis tab.';

      setPrompt(
        `RESUME SESSION: ${planData.project_name || manifest.system?.name || 'Ignite Zero'}

Latest Plan Summary:
${summary}

Consultant Notes:
${consultNote}

${mockupNote}

New Instructions:
- `,
      );
      setResponse(`${markdown}\n\n---\n${mockupNote}`);
      toast.success('Loaded last session details.');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to load last session.');
    } finally {
      setResumeLoading(false);
    }
  };

  return (
    <BuilderShell>
    <div className="min-h-screen bg-slate-950 text-slate-200 font-mono flex flex-col">
      
      {/* GLOBAL HEADER */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur px-6 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2 tracking-tight">
          <span className="text-xl">🔥</span> 
          <span className="font-bold text-slate-100">Ignite Zero</span>
        </div>
        <div className="text-xs text-slate-600 font-mono">v2.0.0-platinum</div>
      </header>

      <div className="px-6 py-4 bg-slate-950 border-b border-slate-900">
        <FactoryGuide />
      </div>

      <Tabs defaultValue="create" className="flex-1 flex flex-col">
        {/* NAVIGATION BAR */}
        <div className="border-b border-slate-800 bg-slate-900/50">
          <div className="container mx-auto px-6">
            <TabsList className="bg-transparent border-b-0 h-14 space-x-1 p-0 w-full justify-start">
              <TabsTrigger 
                value="create" 
                className="h-full px-6 rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-500 data-[state=active]:bg-emerald-500/5 data-[state=active]:text-emerald-400 transition-all"
              >
                ✨ Create New
              </TabsTrigger>
              <TabsTrigger 
                value="modify"
                className="h-full px-6 rounded-none border-b-2 border-transparent data-[state=active]:border-cyan-500 data-[state=active]:bg-cyan-500/5 data-[state=active]:text-cyan-400 transition-all"
              >
                🔧 Modify Existing
              </TabsTrigger>
              <TabsTrigger 
                value="monitor"
                className="h-full px-6 rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-blue-500/5 data-[state=active]:text-blue-400 transition-all"
              >
                👀 Monitor
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        {/* CONTENT PANELS */}
        <div className="flex-1 bg-slate-950 container mx-auto px-6 py-8 max-w-7xl">
          
          {/* TAB 1: GENESIS (The Product) */}
          <TabsContent value="create" className="m-0 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <SystemGenesis />
          </TabsContent>

          {/* TAB 2: EVOLUTION (The Tool) */}
          <TabsContent value="modify" className="m-0 h-full animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid gap-8 lg:grid-cols-2 h-full">
              {/* Input Panel */}
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="h-1 w-1 rounded-full bg-cyan-400 animate-pulse" />
                    <label className="text-xs font-medium uppercase tracking-wider text-slate-400">
                      Refactoring Instructions
                    </label>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10"
                    onClick={handleResumeSession}
                    disabled={resumeLoading}
                  >
                    {resumeLoading && <Loader2 className="h-3.5 w-3.5 animate-spin mr-2" />}
                    Resume Session
                  </Button>
                </div>
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[400px] bg-slate-900 border-slate-800 text-slate-100 focus:border-cyan-500/50 focus:ring-cyan-500/20 resize-none font-mono text-sm leading-relaxed p-4"
                  placeholder="e.g. Refactor the 'Task' entity to support sub-tasks and add a 'priority' field..."
                />
                <Button 
                  onClick={runEvolution} 
                  disabled={loading || !prompt} 
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold shadow-lg shadow-cyan-500/20 py-6"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  {loading ? 'Analyzing System...' : 'Execute Refactor'}
                </Button>
              </div>

              {/* Output Panel */}
              <div className="flex flex-col h-full">
                <div className="rounded-lg border border-slate-800 bg-slate-900/50 overflow-hidden flex flex-col h-full min-h-[400px]">
                  <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-900">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-400">Evolution Plan</span>
                    </div>
                    {response !== 'Awaiting instructions...' && response !== 'Processing request...' && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 px-3 hover:bg-slate-800 text-slate-400 hover:text-emerald-400"
                        onClick={copyOutput}
                      >
                        {copied ? (
                          <>
                            <Check className="h-3.5 w-3.5 mr-1.5" />
                            <span className="text-xs font-medium">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5 mr-1.5" />
                            <span className="text-xs font-medium">Copy</span>
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                  <div className="p-5 text-sm text-slate-100 overflow-auto flex-1 prose prose-invert prose-slate max-w-none prose-headings:text-slate-100 prose-code:text-cyan-400 prose-pre:bg-slate-950 prose-pre:border prose-pre:border-slate-800">
                    <ReactMarkdown>{response}</ReactMarkdown>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* TAB 3: WATCHTOWER (The Monitor) */}
          <TabsContent value="monitor" className="m-0 animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            <JobWatchtower />
            <ConsultLogWatchtower />
          </TabsContent>

        </div>
      </Tabs>
    </div>
    </BuilderShell>
  );
}
