import { BuilderShell } from "@/components/dev/BuilderShell";

export default function MyNewApp() {
  return (
    <BuilderShell>
      <div className="min-h-screen bg-slate-950 text-slate-200 flex items-center justify-center px-6 py-16">
        <div className="max-w-lg text-center space-y-4">
          <p className="text-xs font-mono uppercase tracking-[0.4em] text-slate-500">
            My New App
          </p>
          <h1 className="text-4xl font-bold text-white">
            Blank canvas ready for your first screen
          </h1>
          <p className="text-slate-400 text-sm leading-relaxed">
            This placeholder page represents the first page of your generated
            app. Use the Architect Console to define requirements, then we&rsquo;ll
            hydrate this space with real UI once the plan is executed.
          </p>
        </div>
      </div>
    </BuilderShell>
  );
}


