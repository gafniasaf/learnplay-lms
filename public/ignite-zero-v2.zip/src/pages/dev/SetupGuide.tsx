import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const commands = [
  {
    label: "Install dependencies",
    value: "npm install",
  },
  {
    label: "Launch the Factory menu",
    value: "npm run factory",
  },
  {
    label: "Prepare storage bucket",
    value: "npm run storage:setup",
  },
];

const lovableSteps = [
  "Log into Lovable, create a new blank project.",
  "Upload the same ZIP into Lovable or copy the folder contents there.",
  "Run `npm install` in Lovable’s console, then `npm run dev:up`.",
  "Point Lovable’s preview to `/architect`.",
];

const envZip = import.meta.env.VITE_RELEASE_ZIP_URL;
const fallbackZipUrl =
  typeof envZip === "string" && envZip.length > 0
    ? envZip
    : "/ignite-zero-release.zip";

export default function SetupGuide() {
  const copy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const [bootstrapCommand, setBootstrapCommand] = useState(
    "Set-ExecutionPolicy Bypass -Scope Process -Force; iwr https://your-domain/install-factory.ps1 -UseBasicParsing | iex",
  );
  const [downloadLoading, setDownloadLoading] = useState(false);
  const [lastSignedUrl, setLastSignedUrl] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const origin = window.location.origin;
      setBootstrapCommand(
        `Set-ExecutionPolicy Bypass -Scope Process -Force; iwr ${origin}/install-factory.ps1 -UseBasicParsing | iex`,
      );
    }
  }, []);

  const handleSecureDownload = async () => {
    setDownloadLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("download-release");
      if (error) throw error;
      if (!data?.url) throw new Error("Missing download URL");
      setLastSignedUrl(data.url);
      window.location.href = data.url;
    } catch (err) {
      console.warn("Secure download failed, falling back to static zip:", err);
      toast.error(
        err instanceof Error
          ? `${err.message}. Falling back to bundled zip.`
          : "Secure download unavailable. Falling back to bundled zip."
      );
      window.location.href = fallbackZipUrl;
    } finally {
      setDownloadLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto py-10 space-y-8">
      <div className="space-y-2">
        <p className="text-xs uppercase tracking-wider text-slate-500 font-mono">
          Ignite Zero
        </p>
        <h1 className="text-3xl font-bold text-white">Download & Setup</h1>
        <p className="text-slate-400 text-sm max-w-3xl">
          Non-coders can follow these exact steps to spin up a local copy of the
          Factory, connect it to Cursor, and optionally mirror it inside Lovable.
        </p>
      </div>

      <Card className="bg-slate-950 border-slate-800">
        <CardHeader>
          <CardTitle className="text-xl text-slate-100">
            Zero-Click Bootstrap (PowerShell)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-slate-300">
            Download the helper script, run it in an elevated PowerShell
            session, and it will install Git, Node, Supabase CLI, Docker
            Desktop, and download the latest Ignite Zero release for you.
          </p>
          <p className="text-xs text-emerald-200/80">
            Requires login. We generate a one-time link for you when you click download. If Supabase
            is offline, we automatically fall back to the bundled <code>ignite-zero-release.zip</code>.
          </p>
          {lastSignedUrl && (
            <div className="mt-3 space-y-2 text-xs text-slate-400">
              <p>Need to feed the PowerShell installer directly?</p>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono break-all">
                .\install-factory.ps1 -ReleaseUrl "{lastSignedUrl}"
              </div>
              <p className="text-[10px] text-slate-500">
                This link expires in about an hour for security.
              </p>
            </div>
          )}
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              asChild
              className="bg-emerald-600 hover:bg-emerald-500 flex-1"
            >
              <a href="/install-factory.ps1" download>
                ⬇️ Download install-factory.ps1
              </a>
            </Button>
            <Button
              variant="outline"
              className="flex-1 border-slate-700 text-slate-200"
              onClick={() => copy(bootstrapCommand)}
            >
              Copy one-line command
            </Button>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs text-slate-200 relative">
            <button
              className="absolute top-3 right-3 text-slate-400 hover:text-white"
              onClick={() => copy(bootstrapCommand)}
            >
              <Copy className="h-4 w-4" />
            </button>
            <pre className="whitespace-pre-wrap">{bootstrapCommand}</pre>
          </div>
          <ol className="list-decimal list-inside text-sm text-slate-400 space-y-1">
            <li>Open PowerShell as Administrator.</li>
            <li>
              Run the command above to download + execute the script (or download
              it manually and run <code>.\install-factory.ps1</code>).
            </li>
            <li>Wait for the installers to finish, then run `npm run factory`.</li>
          </ol>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800">
        <CardHeader>
          <CardTitle className="text-xl text-slate-100">
            Step 1 · Download the Starter ZIP
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-slate-300">
            Click the button below to download the latest Ignite Zero release.
            When a new version is available, we’ll replace the hosted ZIP and
            this button will pull the fresh copy.
          </p>
          <Button
            onClick={handleSecureDownload}
            className="bg-emerald-600 hover:bg-emerald-500"
            disabled={downloadLoading}
          >
            {downloadLoading ? "Preparing download..." : "⬇️ Download ignite-zero.zip"}
          </Button>
          <ol className="text-sm text-slate-400 space-y-2 list-decimal list-inside">
            <li>Unzip the file somewhere easy, e.g. Desktop/IgniteZero.</li>
            <li>Open <strong>Cursor → Link folder</strong> and select the unzipped folder.</li>
            <li>Open a terminal inside Cursor (or your local terminal).</li>
          </ol>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800">
        <CardHeader>
          <CardTitle className="text-xl text-slate-100">
            Step 2 · Run the Guided Commands
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-slate-300">
            Copy each command below into the terminal or Cursor’s shell in
            order. These scripts match the same ones we use internally, so
            nothing surprising happens.
          </p>
          <div className="grid gap-3 md:grid-cols-3">
            {commands.map((cmd) => (
              <div
                key={cmd.label}
                className="border border-slate-800 rounded-lg p-4 space-y-2 bg-slate-900/40"
              >
                <p className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  {cmd.label}
                </p>
                <div className="flex items-center gap-2 text-sm font-mono text-slate-100 bg-slate-950 border border-slate-800 rounded-md px-2 py-1">
                  <span className="truncate">{cmd.value}</span>
                  <button
                    className="ml-auto text-cyan-400"
                    onClick={() => copy(cmd.value)}
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <ul className="list-disc list-inside text-xs text-slate-500 space-y-1">
            <li>`npm run factory` opens the simple menu so teammates can press 1 to start and the browser opens to /architect.</li>
            <li>If the storage warning appears, run `npm run storage:setup` (you can paste it into Cursor’s terminal too).</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800">
        <CardHeader>
          <CardTitle className="text-xl text-slate-100">
            Step 3 · Optional Lovable Deployment
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-slate-300">
            Need a hosted preview? Mirror the same ZIP inside Lovable using
            these instructions:
          </p>
          <ol className="list-decimal list-inside text-sm text-slate-300 space-y-2">
            {lovableSteps.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800">
        <CardHeader>
          <CardTitle className="text-xl text-slate-100">
            Step 4 · Hand Off to Cursor
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-slate-300">
          <p>
            Once the system is running locally, go to <strong>/architect</strong>, generate a plan,
            click “Download PLAN.md”, and copy the Cursor Instructions text.
          </p>
          <p>
            In Cursor chat, paste the instruction text (e.g. “Download PLAN.md
            from https://... and execute Phase 1”). That’s it—Cursor now has
            everything it needs.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

