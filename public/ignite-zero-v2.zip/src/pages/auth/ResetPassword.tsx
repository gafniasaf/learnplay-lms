export default function ResetPassword() {
  return <div>Reset Password</div>;
}
