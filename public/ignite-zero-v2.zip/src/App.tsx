import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { lazy, Suspense } from "react";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { BuilderShell } from "@/components/dev/BuilderShell";
import { useSentryUser } from "./hooks/useSentryUser";

const Auth = lazy(() => import("./pages/Auth"));
const ResetPassword = lazy(() => import("./pages/auth/ResetPassword"));
const ArchitectConsole = lazy(() => import("./pages/dev/ArchitectConsole"));
const MyNewApp = lazy(() => import("./pages/dev/MyNewApp"));
const SetupGuide = lazy(() => import("./pages/dev/SetupGuide"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

// Component to set up Sentry user context
const SentryUserProvider = ({ children }: { children: React.ReactNode }) => {
  useSentryUser();
  return <>{children}</>;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <SentryUserProvider>
            <Suspense fallback={<div className="flex items-center justify-center min-h-screen">Loading...</div>}>
              <Routes>
                <Route path="/auth" element={<Auth />} />
                <Route path="/auth/reset-password" element={<ResetPassword />} />
                <Route
                  path="/architect"
                  element={
                    <ProtectedRoute>
                      <BuilderShell>
                        <ArchitectConsole />
                      </BuilderShell>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/my-app"
                  element={
                    <ProtectedRoute>
                      <BuilderShell>
                        <MyNewApp />
                      </BuilderShell>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/setup"
                  element={
                    <ProtectedRoute>
                      <BuilderShell>
                        <SetupGuide />
                      </BuilderShell>
                    </ProtectedRoute>
                  }
                />
                <Route path="/" element={<Navigate to="/architect" replace />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </SentryUserProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
