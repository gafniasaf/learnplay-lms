import { test, expect } from '@playwright/test';

// TODO: These tests need to be updated to match the current System Genesis wizard flow
// The UI has evolved significantly and the selectors no longer match
// Skipping until the wizard UI stabilizes
test.describe.skip('Mockup Orchestrator', () => {
  test.beforeEach(async ({ page }) => {
    // Mock the architect-advisor edge function for all tests
    await page.route('**/functions/v1/architect-advisor', async (route, request) => {
      const body = request.postDataJSON();

      if (body.mode === 'analyze-document') {
        // Mock document classification
        const sections = body.sections || [];
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            result: JSON.stringify({
              sections: sections.map((s: any) => ({
                heading: s.heading,
                type: 'ui_page',
                reason: 'Mocked classification'
              }))
            })
          }),
        });
        return;
      }

      if (body.mode === 'mockup-lane') {
        // Mock successful lane generation
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            result: JSON.stringify({
              laneId: body.laneId,
              status: 'ready',
              html: `<html><head><title>${body.laneId}</title></head><body><h1>${body.laneId} Mockup</h1><a href="dashboard">Go to Dashboard</a></body></html>`,
              diagnostics: []
            })
          }),
        });
        return;
      }

      if (body.mode === 'mockup-critique') {
        // Mock critique response
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            result: JSON.stringify({
              verdict: 'needs_revision',
              missing_screens: ['Reports Dashboard'],
              redundant_screens: [],
              journey_issues: ['No navigation from Home to Reports'],
              suggestions: ['Add a Reports lane with analytics widgets'],
            }),
          }),
        });
        return;
      }

      if (body.mode === 'decode') {
        // Mock decode to progress wizard
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            result: JSON.stringify({
              project_name: 'Test System',
              analysis: { 
                archetype: 'Platform', 
                summary: 'A test system for E2E validation', 
                pros: ['Fast iteration'], 
                cons: ['Limited scale'] 
              },
              steps: [
                { id: 1, title: 'Genesis: Create Manifest', cursor_prompt: 'Generate manifest...' },
                { id: 2, title: 'UI: Build Dashboard', cursor_prompt: 'Build dashboard...' }
              ]
            })
          }),
        });
        return;
      }

      // Default fallback
      await route.continue();
    });

    await page.goto('/architect');
    await page.waitForLoadState('networkidle');
  });

  test('detects provided HTML mockups from pasted document', async ({ page }) => {
    const sampleDoc = `
## Login Page
This is the login screen.

\`\`\`html
<html>
<head><title>Login</title></head>
<body><h1>Login</h1><form><input type="email" /><button>Sign In</button></form></body>
</html>
\`\`\`

## Dashboard
Main dashboard view.

\`\`\`html
<html>
<head><title>Dashboard</title></head>
<body><h1>Dashboard</h1><div class="stats">Stats here</div></body>
</html>
\`\`\`
`;

    // Wait for the main textarea to appear (Step 0)
    const textarea = page.locator('textarea[placeholder*="Dog Walking"]');
    await textarea.waitFor({ state: 'visible', timeout: 15000 });
    await textarea.fill(sampleDoc);

    // Click Design My System button to trigger decode
    const designButton = page.getByRole('button', { name: /design my system/i });
    await designButton.click();

    // Wait for decode to complete and wizard to show Step 1 (Strategy Review)
    await expect(page.getByText(/Test System/i)).toBeVisible({ timeout: 15000 });

    // Wait for mockup orchestrator to appear (should be in Step 1)
    await expect(page.getByText('Blueprint Mockup Orchestrator')).toBeVisible({ timeout: 15000 });

    // Provided mockups are ready immediately
    await expect(page.getByText(/2 \/ 2 lanes ready/)).toBeVisible({ timeout: 10000 });

    // Verify lane buttons exist in the sidebar
    await expect(page.getByText('Login Page').first()).toBeVisible();
    await expect(page.getByText('Dashboard').first()).toBeVisible();
  });

  test('generates mockups for text-only sections', async ({ page }) => {
    const textOnlyDoc = `
## Home Screen
Landing page with hero and features.

## Settings
User profile management.
`;

    const textarea = page.locator('textarea[placeholder*="Dog Walking"]');
    await textarea.waitFor({ state: 'visible', timeout: 15000 });
    await textarea.fill(textOnlyDoc);

    const designButton = page.getByRole('button', { name: /design my system/i });
    await designButton.click();

    // Wait for decode and mockup orchestrator
    await expect(page.getByText('Blueprint Mockup Orchestrator')).toBeVisible({ timeout: 15000 });

    // Wait for the Generate button to appear and click it
    const generateButton = page.getByRole('button', { name: /generate blueprints/i });
    await generateButton.click();

    // Wait for generation to complete (mocked)
    await expect(page.getByText(/2 \/ 2 lanes ready/)).toBeVisible({ timeout: 30000 });

    await expect(page.getByText('Home Screen').first()).toBeVisible();
    await expect(page.getByText('Settings').first()).toBeVisible();
  });

  test('handles mixed provided and missing mockups', async ({ page }) => {
    const mixedDoc = `
## Login
\`\`\`html
<html><body><h1>Login</h1></body></html>
\`\`\`

## Dashboard
No mockup provided, generate from context.
`;

    const textarea = page.locator('textarea[placeholder*="Dog Walking"]');
    await textarea.waitFor({ state: 'visible', timeout: 15000 });
    await textarea.fill(mixedDoc);

    const designButton = page.getByRole('button', { name: /design my system/i });
    await designButton.click();

    await expect(page.getByText('Blueprint Mockup Orchestrator')).toBeVisible({ timeout: 15000 });

    // One is pending, so we need to generate
    const generateButton = page.getByRole('button', { name: /generate blueprints/i });
    await generateButton.click();

    // Wait for generation to complete
    await expect(page.getByText(/2 \/ 2 lanes ready/)).toBeVisible({ timeout: 30000 });

    await expect(page.getByText('Login').first()).toBeVisible();
    await expect(page.getByText('Dashboard').first()).toBeVisible();
  });

  test('supports responsive preview toggles and product critic review', async ({ page }) => {
    const doc = `
## Home
Primary landing screen with hero + stats.

## Reports
Analytics drill-down page.
`;

    const textarea = page.locator('textarea[placeholder*="Dog Walking"]');
    await textarea.waitFor({ state: 'visible', timeout: 15000 });
    await textarea.fill(doc);

    const designButton = page.getByRole('button', { name: /design my system/i });
    await designButton.click();

    await expect(page.getByText('Blueprint Mockup Orchestrator')).toBeVisible({ timeout: 15000 });

    // Need to generate to get the iframe and critique
    const generateButton = page.getByRole('button', { name: /generate blueprints/i });
    await generateButton.click();

    // Wait for generation
    await expect(page.getByText(/2 \/ 2 lanes ready/)).toBeVisible({ timeout: 30000 });

    // Wait for iframe to be present
    const iframeEl = page.locator('iframe[title="Lane preview"]').first();
    await expect(iframeEl).toBeVisible({ timeout: 10000 });

    // Test viewport toggles - look for buttons with exact text
    const mobileButton = page.getByRole('button', { name: /^Mobile$/i });
    const desktopButton = page.getByRole('button', { name: /^Desktop$/i });

    // Start with desktop
    if (await desktopButton.isVisible()) {
      await desktopButton.click();
      await page.waitForTimeout(200);
    }
    const desktopWidth = await iframeEl.evaluate((el) => el.getBoundingClientRect().width);

    // Switch to mobile
    if (await mobileButton.isVisible()) {
      await mobileButton.click();
      await page.waitForTimeout(300);
      const mobileWidth = await iframeEl.evaluate((el) => el.getBoundingClientRect().width);
      expect(mobileWidth).toBeLessThan(desktopWidth);
    }

    // Check Product Critic appears
    await expect(page.getByText('Product Critic')).toBeVisible({ timeout: 15000 });
    await expect(page.getByText(/Needs Revision|Approved/i)).toBeVisible();
  });
});
