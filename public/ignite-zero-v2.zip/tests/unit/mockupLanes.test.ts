import { buildLaneSpecs } from '../../src/lib/mockupLanes';

describe('buildLaneSpecs', () => {
  const SAMPLE_DOC = [
    '## Admin Course Editor',
    'Render the admin editor exactly as described.',
    '',
    '```html',
    '<html>',
    '  <body>',
    '    <aside class="sidebar">Sidebar</aside>',
    '    <div class="editor-tabs">Tabs</div>',
    '  </body>',
    '</html>',
    '```',
  ].join('\n');

  it('detects provided HTML per lane when embedded in the document (no LLM)', async () => {
    const specs = await buildLaneSpecs(SAMPLE_DOC);
    expect(specs.length).toBeGreaterThanOrEqual(1);
    expect(specs[0].providedHtml).toContain('<html>');
    expect(specs[0].content).toMatch(/REQUIRED ELEMENTS/i);
  });

  it('applies required elements checklist to all lanes', async () => {
    const specs = await buildLaneSpecs(SAMPLE_DOC);
    specs.forEach((spec) => {
      if (spec.validationHints.length) {
        expect(spec.content).toMatch(/REQUIRED ELEMENTS/i);
      }
    });
  });

  it('handles multi-page documents with different names', async () => {
    const multiDoc = [
      '## Welcome Screen',
      '```html',
      '<html><body><h1>Welcome</h1></body></html>',
      '```',
      '',
      '## Settings Page',
      '```html',
      '<html><body><form>Settings</form></body></html>',
      '```',
    ].join('\n');

    const specs = await buildLaneSpecs(multiDoc);
    expect(specs.length).toBeGreaterThanOrEqual(2);
    expect(specs.some((s) => s.providedHtml?.includes('Welcome'))).toBe(true);
    expect(specs.some((s) => s.providedHtml?.includes('Settings'))).toBe(true);
  });

  it('falls back to templates when no HTML is provided', async () => {
    const plainDoc = 'Build a CRM with dashboard and settings.';
    const specs = await buildLaneSpecs(plainDoc);
    expect(specs.length).toBeGreaterThan(0);
    expect(specs.every((s) => !s.providedHtml)).toBe(true);
  });

  it('generates lanes from text-only sections', async () => {
    const textDoc = [
      '## Login Screen',
      'Users enter email and password.',
      '',
      '## Dashboard',
      'Show revenue charts and appointments.',
    ].join('\n');

    const specs = await buildLaneSpecs(textDoc);
    expect(specs.length).toBeGreaterThanOrEqual(2);
    expect(specs.every((s) => !s.providedHtml)).toBe(true);
  });

  it('handles mixed provided and missing mockups', async () => {
    const mixedDoc = [
      '## Home',
      '```html',
      '<html><body><h1>Home</h1></body></html>',
      '```',
      '',
      '## Settings',
      'User can update profile.',
    ].join('\n');

    const specs = await buildLaneSpecs(mixedDoc);
    expect(specs.length).toBeGreaterThanOrEqual(1);
    expect(specs.some((s) => s.providedHtml?.includes('Home'))).toBe(true);
  });

  it('extracts raw HTML blocks without section wrappers', async () => {
    const rawDoc = `
Some intro text here.

<!DOCTYPE html>
<html lang="en">
<head><title>Login Page</title></head>
<body><h1>Login</h1></body>
</html>

More text in between.

<!DOCTYPE html>
<html lang="en">
<head><title>Dashboard</title></head>
<body><h1>Dashboard</h1></body>
</html>
`;

    const specs = await buildLaneSpecs(rawDoc);
    expect(specs.length).toBe(2);
    expect(specs[0].title).toBe('Login Page');
    expect(specs[1].title).toBe('Dashboard');
    expect(specs[0].providedHtml).toContain('Login');
    expect(specs[1].providedHtml).toContain('Dashboard');
  });
});

