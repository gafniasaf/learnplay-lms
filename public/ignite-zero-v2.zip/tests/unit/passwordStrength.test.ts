import { calculatePasswordStrength } from '@/lib/utils/passwordStrength';

describe('password strength utility', () => {
  it('scores strong passwords higher than weak ones', () => {
    const weak = calculatePasswordStrength('abc123');
    const strong = calculatePasswordStrength('Ignite!2025#Architect');
    expect(strong.score).toBeGreaterThan(weak.score);
    expect(['good', 'strong']).toContain(strong.strength);
    expect(weak.strength).toBe('weak');
  });
});
