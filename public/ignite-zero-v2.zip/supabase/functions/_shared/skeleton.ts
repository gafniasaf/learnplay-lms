// supabase/functions/_shared/skeleton.ts
// Deterministic skeleton builder - creates course structure without LLM

export interface SkeletonParams {
  subject: string;
  grade: string | null;
  itemsPerGroup: number;
  levelsCount?: number;
  mode: "options" | "numeric";
  format?: string;
}

export interface SkeletonCourse {
  // Fixed structure (never modified by LLM)
  id: string;
  title: string;
  description: string;
  subject: string;
  gradeBand: string;
  contentVersion: string;
  
  groups: Array<{
    id: number;
    name: string;
  }>;
  
  levels: Array<{
    id: number;
    title: string;
    start: number;
    end: number;
  }>;
  
  // Scaffolds for LLM to fill
  studyTexts: Array<{
    id: string;
    title: string;  // LLM can refine
    order: number;
    content: string; // Placeholder for LLM to fill
  }>;
  
  items: Array<{
    id: number;
    text: string;           // Placeholder with [blank] - LLM fills
    groupId: number;        // Fixed
    clusterId: string;      // Fixed
    variant: "1" | "2" | "3"; // Fixed
    mode: "options" | "numeric"; // Fixed
    
    // Math metadata for validation (optional)
    _meta?: {
      op?: "add" | "sub" | "mul" | "div";
      a?: number;
      b?: number;
      expected?: number;
    };
    
    // To be filled by LLM:
    options?: string[];     // For options mode
    correctIndex?: number;  // For options mode
    answer?: number;        // For numeric mode
  }>;
}

/**
 * Deterministic RNG for reproducible skeletons
 */
function createRNG(seed: string) {
  let s = 0;
  for (let i = 0; i < seed.length; i++) {
    s = (s * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

/**
 * Detect subject type and decide groups/structure
 */
function analyzeSubject(subject: string) {
  const norm = subject.toLowerCase();
  const hasMul = /(multiplication|multiply|times|product)/i.test(norm);
  const hasDiv = /(division|divide|quotient)/i.test(norm);
  const hasAdd = /(addition|add|plus|sum)/i.test(norm);
  const hasSub = /(subtraction|subtract|substraction|minus)/i.test(norm);
  
  const ops: Array<"add" | "sub" | "mul" | "div"> = [];
  if (hasMul) ops.push("mul");
  if (hasDiv) ops.push("div");
  if (hasAdd) ops.push("add");
  if (hasSub) ops.push("sub");
  
  const isMath = ops.length > 0 || /\bmath\b/i.test(norm);
  
  return {
    isMath,
    ops: ops.length > 0 ? ops.slice(0, 3) : (isMath ? ["add", "sub"] : []),
    isLanguage: !isMath && /(language|english|grammar|writing|reading)/i.test(norm),
    isScience: /\b(science|biology|chemistry|physics|anatomy|kidney|heart|cell)\b/i.test(norm),
  };
}

/**
 * Build deterministic skeleton
 */
export function buildSkeleton(params: SkeletonParams): SkeletonCourse {
  const { subject, grade, itemsPerGroup, levelsCount, mode } = params;
  
  const seedStr = `${subject}|${grade}|${itemsPerGroup}|${levelsCount}|${mode}`;
  const rng = createRNG(seedStr);
  
  const analysis = analyzeSubject(subject);
  const courseId = subject.replace(/[^a-z0-9-]/gi, "-").toLowerCase();
  const gradeBand = grade || "All Grades";
  
  // Build groups
  const groups: SkeletonCourse["groups"] = [];
  
  if (analysis.isMath && analysis.ops.length > 0) {
    // Math: 1 group per operation
    analysis.ops.forEach((op, idx) => {
      const name =
        op === "mul" ? "Multiplication" :
        op === "div" ? "Division" :
        op === "add" ? "Addition" :
        "Subtraction";
      groups.push({ id: idx, name });
    });
  } else {
    // Non-math: create 2-3 thematic groups
    const groupCount = 2 + Math.floor(rng() * 2); // 2 or 3
    for (let i = 0; i < groupCount; i++) {
      groups.push({
        id: i,
        name: `${subject} - Part ${i + 1}`,
      });
    }
  }
  
  // Build item scaffolds
  const items: SkeletonCourse["items"] = [];
  let itemId = 0;
  
  groups.forEach((group, gIdx) => {
    for (let i = 0; i < itemsPerGroup; i++) {
      const clusterId = `${group.name.toLowerCase().replace(/\s+/g, "-")}-cluster-${Math.floor(i / 3)}`;
      const variant = String(((i % 3) + 1)) as "1" | "2" | "3";
      
      // For math, embed metadata
      let meta: SkeletonCourse["items"][0]["_meta"] | undefined;
      if (analysis.isMath && analysis.ops.length > 0) {
        const op = analysis.ops[gIdx % analysis.ops.length] as "add" | "sub" | "mul" | "div";
        let a = 0, b = 0, expected = 0;
        
        switch (op) {
          case "add":
            a = 1 + Math.floor(rng() * 20);
            b = 1 + Math.floor(rng() * 20);
            expected = a + b;
            break;
          case "sub":
            a = 5 + Math.floor(rng() * 20);
            b = Math.floor(rng() * Math.min(a, 10));
            expected = a - b;
            break;
          case "mul":
            a = 2 + Math.floor(rng() * 8);
            b = 2 + Math.floor(rng() * 8);
            expected = a * b;
            break;
          case "div":
            expected = 2 + Math.floor(rng() * 8);
            b = 2 + Math.floor(rng() * 8);
            a = expected * b;
            break;
        }
        
        meta = { op, a, b, expected };
      }
      
      items.push({
        id: itemId++,
        text: "__FILL__", // Placeholder for LLM
        groupId: group.id,
        clusterId,
        variant,
        mode,
        _meta: meta,
      });
    }
  });
  
  // Build levels
  const totalItems = items.length;
  const lvlCount = Math.max(1, Math.min(6, levelsCount ?? 3));
  const levels: SkeletonCourse["levels"] = [];
  const span = Math.max(1, Math.floor(totalItems / lvlCount));
  
  for (let i = 0; i < lvlCount; i++) {
    const start = i * span;
    const end = i === lvlCount - 1 ? totalItems - 1 : Math.min(totalItems - 1, (i + 1) * span - 1);
    levels.push({
      id: i + 1,
      title: `Level ${i + 1}`,
      start,
      end,
    });
  }
  
  // Build study text scaffolds
  const studyTexts: SkeletonCourse["studyTexts"] = [];
  
  if (analysis.isMath && analysis.ops.length > 0) {
    analysis.ops.forEach((op, idx) => {
      const title =
        op === "add" ? "Understanding Addition" :
        op === "sub" ? "Understanding Subtraction" :
        op === "mul" ? "Understanding Multiplication" :
        "Understanding Division";
      
      studyTexts.push({
        id: `study-${op}`,
        title,
        order: idx + 1,
        content: "__FILL__", // LLM will fill with educational content
      });
    });
  } else {
    // Generic study texts
    studyTexts.push({
      id: "study-intro",
      title: `${subject} Introduction`,
      order: 1,
      content: "__FILL__",
    });
    studyTexts.push({
      id: "study-concepts",
      title: `${subject} Key Concepts`,
      order: 2,
      content: "__FILL__",
    });
  }
  
  return {
    id: courseId,
    title: `${subject} Course`,
    description: `Educational course on ${subject}`,
    subject,
    gradeBand,
    contentVersion: `skeleton-${new Date().toISOString()}`,
    groups,
    levels,
    studyTexts,
    items,
  };
}
