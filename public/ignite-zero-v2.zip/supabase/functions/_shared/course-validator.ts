// supabase/functions/_shared/course-validator.ts
// Programmatic course validators - no LLM, pure code checks

import { CourseSchema } from "./validation.ts";
import { countPlaceholders } from "./generation-utils.ts";
import type { FilledCourse } from "./filler.ts";
import { evaluateKnowledgePackGates, BasicKnowledgePack } from "./gates.ts";
import { sanitizeCourseContent } from "./text-sanitizer.ts";
import { validatePhysicsConsistency, PhysicsValidationError } from "./physics-heuristics.ts";

export interface ValidationIssue {
  code: string;
  path: string;
  message: string;
  severity: "error" | "warning";
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

/**
 * Validate filled course
 */
export interface ValidateCourseOptions {
  knowledgePack?: BasicKnowledgePack;
}

export function validateCourse(course: FilledCourse, options: ValidateCourseOptions = {}): ValidationResult {
  const issues: ValidationIssue[] = [];
  sanitizeCourseContent(course as unknown as Record<string, unknown>);
  
  // 1. Schema validation
  try {
    CourseSchema.parse(course);
  } catch (err: any) {
    if (err.errors) {
      for (const zodError of err.errors) {
        issues.push({
          code: "schema_error",
          path: zodError.path.join("."),
          message: zodError.message,
          severity: "error",
        });
      }
    } else {
      issues.push({
        code: "schema_error",
        path: "course",
        message: String(err),
        severity: "error",
      });
    }
  }
  
  // 2. Placeholder validation
  course.items.forEach((item, idx) => {
    const count = countPlaceholders(item.text || "");
    if (count !== 1) {
      issues.push({
        code: "invalid_blank_count",
        path: `items[${idx}].text`,
        message: `Expected exactly 1 [blank], found ${count}`,
        severity: "error",
      });
    }
  });
  
  // 3. Options/numeric validation
  course.items.forEach((item, idx) => {
    if (item.mode === "options") {
      if (!item.options || item.options.length < 3 || item.options.length > 4) {
        issues.push({
          code: "invalid_options_count",
          path: `items[${idx}].options`,
          message: `Options mode requires 3-4 options, found ${item.options?.length || 0}`,
          severity: "error",
        });
      }
      if (item.correctIndex === undefined || item.correctIndex < 0 || item.correctIndex >= (item.options?.length || 0)) {
        issues.push({
          code: "invalid_correct_index",
          path: `items[${idx}].correctIndex`,
          message: `correctIndex out of range`,
          severity: "error",
        });
      }
      
      // Check for duplicate options
      if (item.options && new Set(item.options).size !== item.options.length) {
        issues.push({
          code: "duplicate_options",
          path: `items[${idx}].options`,
          message: `Duplicate options detected`,
          severity: "warning",
        });
      }
    } else if (item.mode === "numeric") {
      if (item.answer === undefined || typeof item.answer !== "number") {
        issues.push({
          code: "missing_answer",
          path: `items[${idx}].answer`,
          message: `Numeric mode requires numeric answer`,
          severity: "error",
        });
      }
      if (item.options !== undefined) {
        issues.push({
          code: "unexpected_options",
          path: `items[${idx}].options`,
          message: `Numeric mode should not have options`,
          severity: "error",
        });
      }
    }
  });
  
  // 4. Math correctness (if metadata exists)
  course.items.forEach((item, idx) => {
    if (item._meta) {
      const { op, a, b, expected } = item._meta;
      
      let actual: number | undefined;
      if (item.mode === "numeric") {
        actual = item.answer;
      } else if (item.mode === "options" && item.correctIndex !== undefined && item.options) {
        const correctOpt = item.options[item.correctIndex];
        actual = parseFloat(correctOpt);
      }
      
      if (actual !== undefined && expected !== undefined && Math.abs(actual - expected) > 0.01) {
        issues.push({
          code: "math_incorrect",
          path: `items[${idx}].${item.mode === "numeric" ? "answer" : "correctIndex"}`,
          message: `Math error: expected ${expected}, got ${actual} (${op}: ${a}, ${b})`,
          severity: "error",
        });
      }
    }
  });
  
  // 5. Study text validation
  course.studyTexts?.forEach((st, idx) => {
    if (!st.content || st.content === "__FILL__") {
      issues.push({
        code: "unfilled_content",
        path: `studyTexts[${idx}].content`,
        message: `Study text content not filled`,
        severity: "error",
      });
    }
    
    // Check for section markers
    if (st.content && !/\[SECTION:/i.test(st.content)) {
      issues.push({
        code: "missing_section_markers",
        path: `studyTexts[${idx}].content`,
        message: `No [SECTION:...] markers found`,
        severity: "warning",
      });
    }
  });
  
  // 6. Item text unfilled check
  course.items.forEach((item, idx) => {
    if (item.text === "__FILL__") {
      issues.push({
        code: "unfilled_text",
        path: `items[${idx}].text`,
        message: `Item text not filled`,
        severity: "error",
      });
    }
  });

  // 7. Knowledge-pack gates (lexicon, banned terms, readability)
  if (options.knowledgePack) {
    const packIssues = evaluateKnowledgePackGates(course, options.knowledgePack);
    for (const issue of packIssues) {
      issues.push({
        code: issue.code,
        path: issue.path,
        message: issue.message,
        severity: "error",
      });
    }
  }

  try {
    validatePhysicsConsistency(course);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    issues.push({
      code: err instanceof PhysicsValidationError ? "physics_inconsistent" : "physics_validation_error",
      path: "items",
      message,
      severity: "error",
    });
  }

  const valid = issues.filter(i => i.severity === "error").length === 0;

  return { valid, issues };
}

/**
 * Simple readability check (approximate grade level)
 */
export function estimateReadabilityGrade(text: string): number {
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  if (sentences.length === 0) return 1;
  
  const words = text.split(/\s+/).filter(w => w.length > 0);
  const syllables = words.reduce((sum, word) => {
    // Rough syllable count: vowel groups
    const matches = word.toLowerCase().match(/[aeiouy]+/g);
    return sum + (matches?.length || 1);
  }, 0);
  
  const avgWordsPerSentence = words.length / sentences.length;
  const avgSyllablesPerWord = syllables / words.length;
  
  // Flesch-Kincaid Grade Level formula (simplified)
  const grade = 0.39 * avgWordsPerSentence + 11.8 * avgSyllablesPerWord - 15.59;
  return Math.max(1, Math.round(grade));
}
