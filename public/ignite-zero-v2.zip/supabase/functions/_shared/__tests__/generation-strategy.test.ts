// @ts-nocheck
import { describe, it, expect, jest } from "@jest/globals";
import { selectGenerationStrategy } from "../generation-strategy.ts";

describe("selectGenerationStrategy", () => {
  const baseInput = {
    subject: "kidneys",
    grade: "Grade 1",
    itemsPerGroup: 6,
    levelsCount: 3,
    mode: "options" as const,
  };

  it("prefers deterministic pack when available", async () => {
    const deterministicCourse = { id: "kidneys-g1", title: "Kidneys Course" } as any;
    const knowledgePack = { pack_id: "kidneys.g1" } as any;
    const generateCourseDeterministic = jest.fn().mockResolvedValue({
      success: true,
      course: deterministicCourse,
      knowledgePack,
      packId: "kidneys.g1",
      packVersion: 1,
      seed: 42,
      errors: [],
    });

    const buildSkeleton = jest.fn();

    const result = await selectGenerationStrategy(baseInput, {
      generateCourseDeterministic,
      buildSkeleton,
    });

    expect(result.kind).toBe("deterministic");
    expect(result.course).toBe(deterministicCourse);
    expect(result.pack.definition).toBe(knowledgePack);
    expect(buildSkeleton).not.toHaveBeenCalled();
  });

  it("falls back to skeleton when no pack is available", async () => {
    const generateCourseDeterministic = jest.fn().mockResolvedValue({ success: false, errors: ["no_pack"] });
    const skeleton = { id: "fallback-course" } as any;
    const buildSkeleton = jest.fn().mockReturnValue(skeleton);

    const result = await selectGenerationStrategy(baseInput, {
      generateCourseDeterministic,
      buildSkeleton,
    });

    expect(result.kind).toBe("skeleton");
    expect(result.skeleton).toBe(skeleton);
    expect(buildSkeleton).toHaveBeenCalledTimes(1);
  });
});

