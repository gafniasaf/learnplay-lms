// @ts-nocheck
import { describe, it, expect, jest } from "@jest/globals";
import { upsertCourseMetadata } from "../metadata.ts";

describe("upsertCourseMetadata", () => {
  const supabase = {
    from: jest.fn().mockReturnThis(),
    select: jest.fn().mockReturnThis(),
    order: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
    maybeSingle: jest.fn().mockResolvedValue({ data: { id: "org-1" } }),
    upsert: jest.fn().mockResolvedValue({ data: null, error: null }),
    insert: jest.fn().mockResolvedValue({ data: null, error: null }),
    rpc: jest.fn().mockResolvedValue({ data: 1, error: null }),
  } as any;

  const course = {
    id: "kidneys-g1",
    title: "Kidneys Course",
    subject: "kidneys",
    gradeBand: "Grade 1",
  } as any;

  it("writes to both course_metadata and courses tables", async () => {
    await upsertCourseMetadata(supabase, course.id, course);

    const tables = supabase.from.mock.calls.map(([table]: any) => table);
    expect(tables).toContain("course_metadata");
    expect(tables).toContain("courses");
  });
});

