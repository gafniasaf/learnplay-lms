// @ts-nocheck
import { validateCourseIntegrity } from "../validation.ts";

describe("validateCourseIntegrity", () => {
  it("returns ok=true for a minimal valid course", () => {
    const course = {
      id: "c-1",
      title: "T",
      contentVersion: "v1",
      groups: [{ id: 0, name: "G" }],
      levels: [{ id: 1, title: "L1", start: 0, end: 0 }],
      items: [{
        id: 0,
        text: "2 + [blank] = 4",
        groupId: 0,
        clusterId: "cl1",
        variant: "1",
        mode: "options",
        options: ["1", "2", "3"],
        correctIndex: 1
      }]
    };
    const res = validateCourseIntegrity(course);
    expect(res.ok).toBe(true);
  });

  it("returns ok=false when options-mode invariants are broken", () => {
    const bad = {
      id: "c-2",
      title: "Bad",
      contentVersion: "v1",
      groups: [{ id: 0, name: "G" }],
      levels: [{ id: 1, title: "L1", start: 0, end: 0 }],
      items: [{
        id: 0,
        text: "a [blank] b",
        groupId: 0,
        clusterId: "cl1",
        variant: "1",
        mode: "options",
        options: ["only-two", "invalid"],
        correctIndex: 2
      }]
    };
    const res = validateCourseIntegrity(bad);
    expect(res.ok).toBe(false);
    expect(String(res.error || '')).toMatch(/options-mode requires options/);
  });
});


