import { buildCoursePrompt } from './prompts.ts';

describe('prompts: buildCoursePrompt with sources', () => {
  it('includes sources section when provided', () => {
    const prompt = buildCoursePrompt({
      subject: 'Kidneys',
      grade: 'Grade 6',
      itemsPerGroup: 8,
      mode: 'options',
      sources: [
        { url: 'https://example.com/a', content: 'Kidney filters blood' },
        { url: 'https://example.com/b', content: 'Nephron structure and function' },
      ],
    });

    expect(prompt).toContain('Research Sources:');
    expect(prompt).toContain('https://example.com/a');
    expect(prompt).toContain('Nephron structure');
  });
});


