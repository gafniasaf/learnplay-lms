import { generateCandidates } from './candidates.ts';
import * as logMod from './log.ts';

jest.mock('./prompts', () => ({
  buildCoursePrompt: jest.fn(() => 'base prompt'),
}));

jest.mock('./log', () => ({
  logInfo: jest.fn(),
  logWarn: jest.fn(),
  logError: jest.fn(),
}));

const ai = { generateJson: jest.fn() };
jest.mock('./ai', () => ({
  generateJson: (...args: any[]) => (ai.generateJson as any)(...args),
  getProvider: jest.fn(() => 'openai'),
  getModel: jest.fn(() => 'gpt-4o-mini'),
}));

function makeCourseJson(title: string) {
  return JSON.stringify({
    subject: 'Math',
    title,
    items: [{ id: 0, text: '2 + 2 = [blank]', groupId: 0, clusterId: 'c', variant: '1' }],
    studyTexts: [{ id: 's1', content: 'Study' }],
    groups: [{ id: 0, name: 'G' }],
    levels: [{ level: 1, itemIds: [0] }],
  });
}

describe('candidates: generateCandidates', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns parsed candidates and metrics for successful results', async () => {
    (ai.generateJson as jest.Mock)
      .mockResolvedValueOnce({ ok: true, text: makeCourseJson('A'), metrics: { tokens: 10 } })
      .mockResolvedValueOnce({ ok: true, text: makeCourseJson('B'), metrics: { tokens: 12 } })
      .mockResolvedValueOnce({ ok: true, text: makeCourseJson('C'), metrics: { tokens: 8 } });

    const { candidates, metrics } = await generateCandidates(
      { subject: 'math', grade: 'g', itemsPerGroup: 3, mode: 'options' },
      3,
      { requestId: 'r' },
      1000
    );

    expect(candidates).toHaveLength(3);
    expect(metrics).toHaveLength(3);
    expect(candidates[0].course.title).toBeDefined();
  });

  it('skips failed and unparseable results, logs warnings, and still returns metrics', async () => {
    (ai.generateJson as jest.Mock)
      .mockResolvedValueOnce({ ok: true, text: makeCourseJson('Same'), metrics: { tokens: 10 } })
      .mockResolvedValueOnce({ ok: false, error: 'api', metrics: { tokens: 0 } }) // failure
      .mockResolvedValueOnce({ ok: true, text: 'not-json', metrics: { tokens: 5 } }); // parse fail

    const { candidates, metrics } = await generateCandidates(
      { subject: 'math', grade: 'g', itemsPerGroup: 3, mode: 'options' },
      3,
      { requestId: 'r' },
      1000
    );

    expect(candidates).toHaveLength(1);
    expect(metrics).toHaveLength(3);
    expect((logMod as any).logWarn).toHaveBeenCalled();
  });

  it('warns when candidates are too similar', async () => {
    const same = makeCourseJson('SAME');
    (ai.generateJson as jest.Mock)
      .mockResolvedValueOnce({ ok: true, text: same, metrics: { tokens: 10 } })
      .mockResolvedValueOnce({ ok: true, text: same, metrics: { tokens: 11 } })
      .mockResolvedValueOnce({ ok: true, text: makeCourseJson('Different'), metrics: { tokens: 12 } });

    await generateCandidates(
      { subject: 'math', grade: 'g', itemsPerGroup: 3, mode: 'options' },
      3,
      { requestId: 'r' },
      1000
    );

    expect((logMod as any).logWarn).toHaveBeenCalledWith(expect.stringContaining('Candidates too similar'), expect.any(Object));
  });
});


