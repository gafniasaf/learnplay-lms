/**
 * Phase 0-1 Tests: Provider Abstraction & Modular Prompts
 * Tests for prompt building functions and template consistency
 */

import {
  SYSTEM_PROMPT,
  SCHEMA_TEMPLATE,
  PEDAGOGY_TEMPLATE,
  SCHEMA_REQUIREMENTS,
  getModeConstraints,
  buildCoursePrompt,
  buildRepairPrompt
} from './prompts.ts';

describe('Phase 0-1: Modular Prompts', () => {
  describe('Prompt Templates', () => {
    it('should have non-empty SYSTEM_PROMPT', () => {
      expect(SYSTEM_PROMPT).toBeTruthy();
      expect(SYSTEM_PROMPT.length).toBeGreaterThan(50);
      expect(SYSTEM_PROMPT).toContain('education');
    });

    it('should have SCHEMA_TEMPLATE with JSON structure', () => {
      expect(SCHEMA_TEMPLATE).toBeTruthy();
      expect(SCHEMA_TEMPLATE).toContain('JSON');
      expect(SCHEMA_TEMPLATE).toContain('[blank]');
      expect(SCHEMA_TEMPLATE).toContain('Output Rules');
    });

    it('should have PEDAGOGY_TEMPLATE with teaching guidelines', () => {
      expect(PEDAGOGY_TEMPLATE).toBeTruthy();
      expect(PEDAGOGY_TEMPLATE.length).toBeGreaterThan(100);
      expect(PEDAGOGY_TEMPLATE).toContain('study');
    });

    it('should have SCHEMA_REQUIREMENTS with field specs', () => {
      expect(SCHEMA_REQUIREMENTS).toBeTruthy();
      expect(SCHEMA_REQUIREMENTS).toContain('id');
      expect(SCHEMA_REQUIREMENTS).toContain('text');
      expect(SCHEMA_REQUIREMENTS).toContain('groupId');
    });
  });

  describe('getModeConstraints', () => {
    it('should return options mode constraints', () => {
      const constraints = getModeConstraints('options');
      
      expect(constraints).toBeTruthy();
      expect(constraints).toContain('OPTIONS');
      expect(constraints).toContain('options');
      expect(constraints).toContain('correctIndex');
    });

    it('should return numeric mode constraints', () => {
      const constraints = getModeConstraints('numeric');
      
      expect(constraints).toBeTruthy();
      expect(constraints).toContain('NUMERIC');
      expect(constraints).toContain('answer');
      expect(constraints).toContain('Do NOT include "options"');
    });

    it('should handle invalid mode gracefully', () => {
      const constraints = getModeConstraints('invalid' as any);
      
      expect(constraints).toBeTruthy();
      expect(typeof constraints).toBe('string');
    });

    it('should require correctIndex in options mode', () => {
      const optionsConstraints = getModeConstraints('options');
      
      expect(optionsConstraints).toContain('correctIndex');
      expect(optionsConstraints).toContain('Do NOT include an "answer"');
      expect(optionsConstraints).toContain('3-4 options');
    });
  });

  describe('buildCoursePrompt', () => {
    it('should build prompt with minimal parameters', () => {
      const prompt = buildCoursePrompt({
        subject: 'Math',
        grade: '5th Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toBeTruthy();
      expect(prompt).toContain('Math');
      expect(prompt).toContain('5th Grade');
      expect(prompt).toContain('12');
      expect(prompt).toContain('options');
    });

    it('should include subject in prompt', () => {
      const prompt = buildCoursePrompt({
        subject: 'Biology: Photosynthesis Basics',
        grade: 'High School',
        itemsPerGroup: 15,
        mode: 'options'
      });

      expect(prompt).toContain('Photosynthesis Basics');
      expect(prompt).toContain('Biology');
    });

    it('should include levelsCount when provided', () => {
      const prompt = buildCoursePrompt({
        subject: 'History',
        grade: 'Middle School',
        itemsPerGroup: 10,
        levelsCount: 5,
        mode: 'numeric'
      });

      expect(prompt).toContain('5');
      expect(prompt).toContain('History');
    });

    it('should handle numeric mode correctly', () => {
      const prompt = buildCoursePrompt({
        subject: 'Algebra',
        grade: '8th Grade',
        itemsPerGroup: 12,
        mode: 'numeric'
      });

      expect(prompt).toContain('numeric');
      expect(prompt).toContain('answer');
      expect(prompt).toContain('NUMERIC'); // From mode constraints
    });

    it('should handle options mode correctly', () => {
      const prompt = buildCoursePrompt({
        subject: 'Science',
        grade: '6th Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toContain('options');
      expect(prompt).toContain('correctIndex');
    });

    it('should include all template sections', () => {
      const prompt = buildCoursePrompt({
        subject: 'English',
        grade: '7th Grade',
        itemsPerGroup: 10,
        mode: 'options'
      });

      // Should contain parts from all templates
      expect(prompt.length).toBeGreaterThan(500);
      expect(prompt).toContain('JSON');
      expect(prompt).toContain('[blank]');
    });

    it('should handle special characters in subject', () => {
      const prompt = buildCoursePrompt({
        subject: 'C++ Programming',
        grade: 'High School',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toContain('C++');
    });

    it('should handle unicode in grade', () => {
      const prompt = buildCoursePrompt({
        subject: 'Français',
        grade: 'Lycée',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toContain('Français');
      expect(prompt).toContain('Lycée');
    });
  });

  describe('buildRepairPrompt', () => {
    const courseContext = {
      subject: 'Mathematics',
      grade: '5th Grade',
      mode: 'options' as const
    };

    const sampleItems = [
      {
        id: 0,
        text: 'What is 2 + 2?',
        options: ['3', '4', '5'],
        correctIndex: 1,
        groupId: 0,
        clusterId: 'c0',
        variant: '1' as const,
        mode: 'options' as const,
        explain: 'Basic addition'
      }
    ];

    it('should build repair prompt with items', () => {
      const prompt = buildRepairPrompt({
        items: sampleItems,
        courseContext,
        reason: 'Missing [blank] placeholder'
      });

      expect(prompt).toBeTruthy();
      expect(prompt).toContain('Regenerate');
      expect(prompt).toContain('Mathematics');
      expect(prompt).toContain('5th Grade');
      expect(prompt).toContain(sampleItems[0].text);
    });

    it('should handle multiple items', () => {
      const multipleItems = [
        ...sampleItems,
        {
          id: 1,
          text: 'What is 3 + 3?',
          options: ['5', '6', '7'],
          correctIndex: 1,
          groupId: 0,
          clusterId: 'c0',
          variant: '2' as const,
          mode: 'options' as const,
          explain: 'Basic addition'
        }
      ];

      const prompt = buildRepairPrompt({
        items: multipleItems,
        courseContext,
        reason: 'Multiple validation failures'
      });

      expect(prompt).toContain('What is 3 + 3');
      expect(prompt).toContain(multipleItems[0].text);
      expect(prompt).toContain(multipleItems[1].text);
    });

    it('should handle numeric mode items', () => {
      const numericItems = [
        {
          id: 0,
          text: 'Calculate 5 × 3 = _',
          answer: 15,
          groupId: 0,
          clusterId: 'c0',
          variant: '1' as const,
          mode: 'numeric' as const,
          explain: 'Multiplication'
        }
      ];

      const prompt = buildRepairPrompt({
        items: numericItems,
        courseContext: { ...courseContext, mode: 'numeric' },
        reason: 'Invalid numeric answer format'
      });

      expect(prompt).toContain('numeric');
      expect(prompt).toContain('Calculate 5');
    });

    it('should include mode constraints in repair prompt', () => {
      const prompt = buildRepairPrompt({
        items: sampleItems,
        courseContext,
        reason: 'Schema validation failed'
      });

      expect(prompt).toContain('[blank]');
      expect(prompt).toContain('options');
    });

    it('should handle empty items array', () => {
      const prompt = buildRepairPrompt({
        items: [],
        courseContext,
        reason: 'Testing empty array'
      });

      expect(prompt).toBeTruthy();
      expect(prompt).toContain('repair');
      expect(prompt).toContain('[]');
    });

    it('should preserve item structure in prompt', () => {
      const complexItem = {
        id: 5,
        text: 'Complex question with [blank]?',
        options: ['Option A', 'Option B', 'Option C', 'Option D'],
        correctIndex: 2,
        groupId: 1,
        clusterId: 'c2',
        variant: '3' as const,
        mode: 'options' as const,
        explain: 'Detailed explanation here'
      };

      const prompt = buildRepairPrompt({
        items: [complexItem],
        courseContext,
        reason: 'Complex item structure needs validation'
      });

      expect(prompt).toContain('Complex question');
      expect(prompt).toContain('Option A');
      expect(prompt).toContain('Option D');
      expect(prompt).toContain('Detailed explanation');
    });
  });

  describe('Prompt Consistency', () => {
    it('should maintain consistent structure across calls', () => {
      const params = {
        subject: 'Science',
        grade: '6th Grade',
        itemsPerGroup: 12,
        mode: 'options' as const
      };

      const prompt1 = buildCoursePrompt(params);
      const prompt2 = buildCoursePrompt(params);

      expect(prompt1).toBe(prompt2);
    });

    it('should produce different prompts for different parameters', () => {
      const prompt1 = buildCoursePrompt({
        subject: 'Math',
        grade: '5th Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      const prompt2 = buildCoursePrompt({
        subject: 'Science',
        grade: '6th Grade',
        itemsPerGroup: 15,
        mode: 'numeric'
      });

      expect(prompt1).not.toBe(prompt2);
    });

    it('should include all required sections in course prompt', () => {
      const prompt = buildCoursePrompt({
        subject: 'Test',
        grade: 'Test Grade',
        itemsPerGroup: 10,
        mode: 'options'
      });

      // Check for presence of key template sections
      expect(prompt).toContain('JSON');
      expect(prompt).toContain('groups');
      expect(prompt).toContain('items');
      expect(prompt).toContain('[blank]');
    });
  });

  describe('Edge Cases', () => {
    it('should handle very long subject names', () => {
      const longSubject = 'A'.repeat(200);
      const prompt = buildCoursePrompt({
        subject: longSubject,
        grade: 'Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toContain(longSubject);
    });

    it('should handle itemsPerGroup at boundaries', () => {
      const prompt1 = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 1,
        mode: 'options'
      });

      const prompt100 = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 100,
        mode: 'options'
      });

      expect(prompt1).toContain('1');
      expect(prompt100).toContain('100');
    });

    it('should handle levelsCount at boundaries', () => {
      const prompt1 = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 12,
        levelsCount: 1,
        mode: 'options'
      });

      const prompt10 = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 12,
        levelsCount: 10,
        mode: 'options'
      });

      expect(prompt1).toContain('1');
      expect(prompt10).toContain('10');
    });

    it('should handle missing optional title', () => {
      const prompt = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toBeTruthy();
      expect(prompt.length).toBeGreaterThan(100);
    });

    it('should handle missing optional levelsCount', () => {
      const prompt = buildCoursePrompt({
        subject: 'Math',
        grade: 'Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      expect(prompt).toBeTruthy();
      expect(prompt.length).toBeGreaterThan(100);
    });
  });

  describe('Prompt Length', () => {
    it('should produce reasonably sized prompts', () => {
      const prompt = buildCoursePrompt({
        subject: 'Math',
        grade: '5th Grade',
        itemsPerGroup: 12,
        mode: 'options'
      });

      // Should be substantial but not excessive
      expect(prompt.length).toBeGreaterThan(200);
      expect(prompt.length).toBeLessThan(10000);
    });

    it('should produce reasonably sized repair prompts', () => {
      const items = Array.from({ length: 5 }, (_, i) => ({
        id: i,
        text: `Question ${i} [blank]?`,
        options: ['A', 'B', 'C'],
        correctIndex: 0,
        groupId: 0,
        clusterId: `c${i}`,
        variant: '1' as const,
        mode: 'options' as const,
        explain: 'Explanation'
      }));

      const prompt = buildRepairPrompt({
        items,
        courseContext: {
          subject: 'Math',
          grade: '5th Grade',
          mode: 'options'
        },
        reason: 'Batch repair test'
      });

      expect(prompt.length).toBeGreaterThan(100);
      expect(prompt.length).toBeLessThan(20000);
    });
  });
});
