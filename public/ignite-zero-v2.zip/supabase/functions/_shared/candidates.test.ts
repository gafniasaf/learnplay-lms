/**
 * Unit tests for candidate-based generation helpers
 * Target: >90% code coverage
 */

import { 
  scoreCandidate, 
  selectBestCandidate,
  type Candidate,
  type ScoringResult,
  type SelfReviewResult,
  type CandidateGenerationConfig
} from './candidates.ts';

// Mock dependencies
jest.mock('./log', () => ({
  logInfo: jest.fn(),
  logWarn: jest.fn(),
  logError: jest.fn(),
}));

jest.mock('./ai', () => ({
  generateJson: jest.fn(),
  getProvider: jest.fn(),
  getModel: jest.fn(),
}));

jest.mock('./prompts', () => ({
  buildCoursePrompt: jest.fn(() => 'mocked prompt'),
}));

jest.mock('./validation', () => {
  const { z } = require('zod');
  
  // Create a mock CourseSchema that validates basic structure
  const Group = z.object({ 
    id: z.number().int().nonnegative(), 
    name: z.string().min(1).max(120),
    color: z.string().optional()
  });
  
  const Level = z.object({
    level: z.number().int().nonnegative(),
    description: z.string().optional(),
    itemIds: z.array(z.number()).optional()
  });
  
  const Item = z.object({
    id: z.number().int().nonnegative(),
    text: z.string().min(1).max(400),
    groupId: z.number().int().nonnegative(),
    clusterId: z.string().min(1).max(64),
    variant: z.enum(["1","2","3"]),
    mode: z.enum(["options", "numeric"]),
    options: z.array(z.string()).optional(),
    correctIndex: z.number().int().nonnegative().optional(),
    answer: z.number().optional(),
  });
  
  const CourseSchema = z.object({
    subject: z.string().min(1),
    title: z.string().min(1).max(120),
    grade: z.string().optional(),
    mode: z.enum(["options", "numeric"]).optional(),
    groups: z.array(Group).min(1),
    levels: z.array(Level).min(1),
    items: z.array(Item).min(1)
  });
  
  return {
    CourseSchema,
  };
});

describe('candidates: scoreCandidate', () => {
  const ctx = { requestId: 'test-123', functionName: 'test' };
  
  const validCourse = {
    subject: 'Math',
    title: 'Addition',
    grade: 'Grade 2',
    mode: 'numeric',
    items: [
      {
        id: 0,
        groupId: 0,
        clusterId: 'add-1',
        variant: '1',
        mode: 'numeric',
        text: '3 + 5 = [blank]',
        answer: 8
      },
      {
        id: 1,
        groupId: 0,
        clusterId: 'add-2',
        variant: '1',
        mode: 'numeric',
        text: '7 + 2 = [blank]',
        answer: 9
      }
    ],
    groups: [
      { id: 0, name: 'Basic Addition', studyText: 'Learn addition' }
    ],
    levels: [
      { level: 1, description: 'Level 1', itemIds: [0, 1] }
    ]
  };
  
  describe('Schema validation', () => {
    it('scores valid course with schema_valid=true', () => {
      const result = scoreCandidate(validCourse, 'numeric', null, ctx);
      
      expect(result.details.schema_valid).toBe(true);
      expect(result.score).toBeGreaterThan(0.5);
      expect(result.issues.length).toBe(0);
    });
    
    it('detects invalid schema and reports issues', () => {
      const invalidCourse = { ...validCourse, items: 'invalid' };
      const result = scoreCandidate(invalidCourse, 'numeric', null, ctx);
      
      expect(result.details.schema_valid).toBe(false);
      expect(result.issues.length).toBeGreaterThan(0);
      // With invalid schema, base score excludes schema (0.3), but may include placeholder/mode defaults
      expect(result.score).toBeLessThanOrEqual(0.55);
    });
    
    it('handles missing required fields', () => {
      const incomplete = { subject: 'Test' };
      const result = scoreCandidate(incomplete, 'numeric', null, ctx);
      
      expect(result.details.schema_valid).toBe(false);
      expect(result.issues.length).toBeGreaterThan(0);
    });
  });
  
  describe('Placeholder validation', () => {
    it('validates single placeholder per item', () => {
      const result = scoreCandidate(validCourse, 'numeric', null, ctx);
      
      expect(result.details.placeholder_valid).toBe(true);
      expect(result.issues.every(issue => !issue.includes('placeholder count'))).toBe(true);
    });
    
    it('detects multiple placeholders', () => {
      const multiPlaceholder = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '[blank] + [blank] = 5',
            answer: 5
          }
        ]
      };
      
      const result = scoreCandidate(multiPlaceholder, 'numeric', null, ctx);
      
      expect(result.details.placeholder_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('placeholder count'))).toBe(true);
      expect(result.score).toBeLessThan(0.7);
    });
    
    it('detects missing placeholders', () => {
      const noPlaceholder = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: 'No placeholder here',
            answer: 5
          }
        ]
      };
      
      const result = scoreCandidate(noPlaceholder, 'numeric', null, ctx);
      
      expect(result.details.placeholder_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('placeholder count (0)'))).toBe(true);
    });
  });
  
  describe('Mode constraints validation', () => {
    it('validates numeric mode requirements', () => {
      const result = scoreCandidate(validCourse, 'numeric', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(true);
    });
    
    it('detects numeric item with options', () => {
      const numericWithOptions = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '3 + 5 = [blank]',
            answer: 8,
            options: ['8', '9', '10'], // Invalid for numeric
            correctIndex: 0
          }
        ]
      };
      
      const result = scoreCandidate(numericWithOptions, 'numeric', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('must not have options'))).toBe(true);
    });
    
    it('detects numeric item without answer', () => {
      const numericNoAnswer = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '3 + 5 = [blank]'
            // Missing answer
          }
        ]
      };
      
      const result = scoreCandidate(numericNoAnswer, 'numeric', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('requires answer'))).toBe(true);
    });
    
    it('validates options mode requirements', () => {
      const optionsCourse = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'What is 3 + 5? [blank]',
            options: ['7', '8', '9'],
            correctIndex: 1
          }
        ]
      };
      
      const result = scoreCandidate(optionsCourse, 'options', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(true);
    });
    
    it('detects invalid option count (too few)', () => {
      const tooFewOptions = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'Pick one [blank]',
            options: ['A', 'B'], // Only 2, need 3-4
            correctIndex: 0
          }
        ]
      };
      
      const result = scoreCandidate(tooFewOptions, 'options', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('requires 3-4 options'))).toBe(true);
    });
    
    it('detects invalid option count (too many)', () => {
      const tooManyOptions = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'Pick one [blank]',
            options: ['A', 'B', 'C', 'D', 'E'], // 5 options, max is 4
            correctIndex: 0
          }
        ]
      };
      
      const result = scoreCandidate(tooManyOptions, 'options', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
    });
    
    it('detects missing correctIndex', () => {
      const noCorrectIndex = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'Pick one [blank]',
            options: ['A', 'B', 'C']
            // Missing correctIndex
          }
        ]
      };
      
      const result = scoreCandidate(noCorrectIndex, 'options', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
      expect(result.issues.some(issue => issue.includes('requires valid correctIndex'))).toBe(true);
    });
    
    it('detects negative correctIndex', () => {
      const negativeIndex = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'Pick one [blank]',
            options: ['A', 'B', 'C'],
            correctIndex: -1
          }
        ]
      };
      
      const result = scoreCandidate(negativeIndex, 'options', null, ctx);
      
      expect(result.details.mode_constraints_valid).toBe(false);
    });
  });
  
  describe('Consistency checks', () => {
    it('penalizes high item length variation', () => {
      const unevenLengths = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: 'Short [blank]',
            answer: 1
          },
          {
            id: 1,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: `${'X'.repeat(300)} [blank]`,
            answer: 2
          }
        ]
      };
      
      const result = scoreCandidate(unevenLengths, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBeLessThan(1.0);
      expect(result.issues.some(issue => issue.includes('uniformity'))).toBe(true);
    });
    
    it('detects empty text items', () => {
      const emptyText = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '',
            answer: 5
          }
        ]
      };
      
      const result = scoreCandidate(emptyText, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBeLessThan(1.0);
      expect(result.issues.some(issue => issue.includes('empty text'))).toBe(true);
    });
    
    it('detects placeholder-only items', () => {
      const placeholderOnly = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '[blank]',
            answer: 5
          }
        ]
      };
      
      const result = scoreCandidate(placeholderOnly, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBeLessThan(1.0);
      expect(result.issues.some(issue => issue.includes('placeholder-only'))).toBe(true);
    });
    
    it('detects math operation mismatch', () => {
      const wrongAnswer = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '3 + 5 = [blank]',
            answer: 10 // Wrong! Should be 8
          }
        ]
      };
      
      const result = scoreCandidate(wrongAnswer, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBeLessThan(1.0);
      expect(result.issues.some(issue => issue.includes('mismatch'))).toBe(true);
    });
    
    it('validates subtraction operations', () => {
      const subtraction = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '12 - 5 = [blank]',
            answer: 7
          }
        ]
      };
      
      const result = scoreCandidate(subtraction, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBe(1.0);
      expect(result.issues.every(issue => !issue.includes('mismatch'))).toBe(true);
    });
    
    it('validates multiplication operations', () => {
      const multiplication = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '3 × 4 = [blank]',
            answer: 12
          }
        ]
      };
      
      const result = scoreCandidate(multiplication, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBe(1.0);
    });
    
    it('validates division operations', () => {
      const division = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            text: '12 ÷ 3 = [blank]',
            answer: 4
          }
        ]
      };
      
      const result = scoreCandidate(division, 'numeric', null, ctx);
      
      expect(result.details.consistency_score).toBe(1.0);
    });
    
    it('detects duplicate options', () => {
      const duplicateOptions = {
        ...validCourse,
        mode: 'options',
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'options',
            text: 'Pick one [blank]',
            options: ['A', 'B', 'A'], // Duplicate 'A'
            correctIndex: 0
          }
        ]
      };
      
      const result = scoreCandidate(duplicateOptions, 'options', null, ctx);
      
      expect(result.details.consistency_score).toBeLessThan(1.0);
      expect(result.issues.some(issue => issue.includes('duplicate options'))).toBe(true);
    });
  });
  
  describe('Self-review integration', () => {
    it('incorporates self-review score into final score', () => {
      const selfReview: SelfReviewResult = {
        overall: 0.9,
        clarity: 0.95,
        age_fit: 0.85,
        correctness: 0.9,
        notes: 'Excellent quality'
      };
      
      const withReview = scoreCandidate(validCourse, 'numeric', selfReview, ctx);
      const withoutReview = scoreCandidate(validCourse, 'numeric', null, ctx);
      
      expect(withReview.score).toBeGreaterThan(withoutReview.score);
      expect(withReview.details.self_review_score).toBe(0.9);
    });
    
    it('handles null self-review', () => {
      const result = scoreCandidate(validCourse, 'numeric', null, ctx);
      
      expect(result.details.self_review_score).toBeUndefined();
      expect(result.score).toBeGreaterThan(0);
    });
    
    it('lower self-review yields lower score than higher self-review', () => {
      const highReview: SelfReviewResult = {
        overall: 0.95,
        clarity: 0.95,
        age_fit: 0.95,
        correctness: 0.95,
        notes: 'Great'
      };
      const lowReview: SelfReviewResult = {
        overall: 0.1,
        clarity: 0.1,
        age_fit: 0.1,
        correctness: 0.1,
        notes: 'Poor'
      };
      
      const high = scoreCandidate(validCourse, 'numeric', highReview, ctx);
      const low = scoreCandidate(validCourse, 'numeric', lowReview, ctx);
      
      expect(low.score).toBeLessThan(high.score);
      // And both should remain within [0,1]
      expect(low.score).toBeGreaterThanOrEqual(0);
      expect(high.score).toBeLessThanOrEqual(1);
    });
  });
  
  describe('Score bounds', () => {
    it('caps score at 1.0', () => {
      const perfect: SelfReviewResult = {
        overall: 1.0,
        clarity: 1.0,
        age_fit: 1.0,
        correctness: 1.0,
        notes: 'Perfect'
      };
      
      const result = scoreCandidate(validCourse, 'numeric', perfect, ctx);
      
      expect(result.score).toBeLessThanOrEqual(1.0);
    });
    
    it('floors score at 0.0', () => {
      const terrible = {
        subject: 'Test',
        items: 'invalid',
      };
      
      const result = scoreCandidate(terrible, 'numeric', null, ctx);
      
      expect(result.score).toBeGreaterThanOrEqual(0.0);
    });
  });
  
  describe('Edge cases', () => {
    it('handles empty items array', () => {
      const emptyItems = { ...validCourse, items: [] };
      const result = scoreCandidate(emptyItems, 'numeric', null, ctx);
      
      expect(result.issues.length).toBeGreaterThan(0);
    });
    
    it('handles missing items property', () => {
      const noItems = { ...validCourse };
      delete (noItems as any).items;
      const result = scoreCandidate(noItems, 'numeric', null, ctx);
      
      expect(result.details.schema_valid).toBe(false);
    });
    
    it('handles items with missing text', () => {
      const noText = {
        ...validCourse,
        items: [
          {
            id: 0,
            groupId: 0,
            clusterId: 'test',
            variant: '1',
            mode: 'numeric',
            answer: 5
            // Missing text
          }
        ]
      };
      
      const result = scoreCandidate(noText, 'numeric', null, ctx);
      
      expect(result.issues.some(issue => issue.includes('placeholder count (0)'))).toBe(true);
    });
  });
});

describe('candidates: selectBestCandidate', () => {
  const ctx = { requestId: 'test-123', functionName: 'test' };
  
  const mockCandidates: Candidate[] = [
    { course: { id: 1 }, index: 0 },
    { course: { id: 2 }, index: 1 },
    { course: { id: 3 }, index: 2 }
  ];
  
  const mockScores: ScoringResult[] = [
    {
      score: 0.6,
      issues: [],
      details: {
        schema_valid: true,
        placeholder_valid: true,
        mode_constraints_valid: true,
        consistency_score: 0.9
      }
    },
    {
      score: 0.8,
      issues: [],
      details: {
        schema_valid: true,
        placeholder_valid: true,
        mode_constraints_valid: true,
        consistency_score: 1.0
      }
    },
    {
      score: 0.7,
      issues: [],
      details: {
        schema_valid: true,
        placeholder_valid: true,
        mode_constraints_valid: true,
        consistency_score: 0.95
      }
    }
  ];
  
  describe('Best candidate selection', () => {
    it('selects candidate with highest score', () => {
      const result = selectBestCandidate(mockCandidates, mockScores, 0.5, ctx);
      
      expect(result).not.toBeNull();
      expect(result!.candidate.index).toBe(1); // Index 1 has score 0.8
      expect(result!.score.score).toBe(0.8);
    });
    
    it('returns first candidate when all have same score', () => {
      const sameScores: ScoringResult[] = [
        { ...mockScores[0], score: 0.7 },
        { ...mockScores[1], score: 0.7 },
        { ...mockScores[2], score: 0.7 }
      ];
      
      const result = selectBestCandidate(mockCandidates, sameScores, 0.5, ctx);
      
      expect(result).not.toBeNull();
      expect(result!.candidate.index).toBe(0);
    });
  });
  
  describe('Minimum viable score threshold', () => {
    it('returns null when best score below threshold', () => {
      const lowScores: ScoringResult[] = [
        { ...mockScores[0], score: 0.3 },
        { ...mockScores[1], score: 0.35 },
        { ...mockScores[2], score: 0.38 }
      ];
      
      const result = selectBestCandidate(mockCandidates, lowScores, 0.40, ctx);
      
      expect(result).toBeNull();
    });
    
    it('returns candidate when exactly at threshold', () => {
      const atThreshold: ScoringResult[] = [
        { ...mockScores[0], score: 0.40 }
      ];
      
      const result = selectBestCandidate([mockCandidates[0]], atThreshold, 0.40, ctx);
      
      expect(result).not.toBeNull();
      expect(result!.score.score).toBe(0.40);
    });
    
    it('accepts high minimum viable score', () => {
      const result = selectBestCandidate(mockCandidates, mockScores, 0.85, ctx);
      
      expect(result).toBeNull(); // None meet 0.85 threshold
    });
    
    it('accepts low minimum viable score', () => {
      const result = selectBestCandidate(mockCandidates, mockScores, 0.1, ctx);
      
      expect(result).not.toBeNull(); // All meet 0.1 threshold
      expect(result!.score.score).toBe(0.8); // Still selects best
    });
  });
  
  describe('Edge cases', () => {
    it('handles empty candidates array', () => {
      const result = selectBestCandidate([], [], 0.5, ctx);
      
      expect(result).toBeNull();
    });
    
    it('handles single candidate above threshold', () => {
      const result = selectBestCandidate(
        [mockCandidates[0]],
        [mockScores[0]],
        0.5,
        ctx
      );
      
      expect(result).not.toBeNull();
      expect(result!.candidate.index).toBe(0);
    });
    
    it('handles single candidate below threshold', () => {
      const lowScore: ScoringResult[] = [{ ...mockScores[0], score: 0.3 }];
      const result = selectBestCandidate(
        [mockCandidates[0]],
        lowScore,
        0.5,
        ctx
      );
      
      expect(result).toBeNull();
    });
    
    it('handles mismatched array lengths gracefully', () => {
      // More scores than candidates
      const extraScores = [...mockScores, { ...mockScores[0] }];
      const result = selectBestCandidate(mockCandidates, extraScores, 0.5, ctx);
      
      expect(result).not.toBeNull();
      expect(result!.candidate.index).toBe(1);
    });
  });
  
  describe('Score ordering', () => {
    it('selects highest when first', () => {
      const scoresHighFirst: ScoringResult[] = [
        { ...mockScores[0], score: 0.9 },
        { ...mockScores[1], score: 0.5 },
        { ...mockScores[2], score: 0.6 }
      ];
      
      const result = selectBestCandidate(mockCandidates, scoresHighFirst, 0.4, ctx);
      
      expect(result!.candidate.index).toBe(0);
    });
    
    it('selects highest when last', () => {
      const scoresHighLast: ScoringResult[] = [
        { ...mockScores[0], score: 0.5 },
        { ...mockScores[1], score: 0.6 },
        { ...mockScores[2], score: 0.9 }
      ];
      
      const result = selectBestCandidate(mockCandidates, scoresHighLast, 0.4, ctx);
      
      expect(result!.candidate.index).toBe(2);
    });
    
    it('selects highest when in middle', () => {
      const result = selectBestCandidate(mockCandidates, mockScores, 0.4, ctx);
      
      expect(result!.candidate.index).toBe(1); // 0.8 is in middle
    });
  });
});
