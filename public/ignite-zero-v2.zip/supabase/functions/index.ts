// Entry point for static analysis tools (e.g., Knip).
// Supabase edge functions are invoked by the Supabase runtime, not imported from here.
// This file intentionally has no imports; individual function directories contain their own index.ts handlers.
export {};


