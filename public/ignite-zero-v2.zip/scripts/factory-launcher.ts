import readline from 'node:readline';
import { spawn } from 'node:child_process';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const runCommand = (command: string, args: string[]) =>
  new Promise<void>((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'inherit', shell: process.platform === 'win32' });
    child.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} ${args.join(' ')} exited with code ${code}`));
    });
  });

const openBrowser = (url: string) => {
  const command =
    process.platform === 'win32'
      ? 'start'
      : process.platform === 'darwin'
      ? 'open'
      : 'xdg-open';
  spawn(command, [url], { stdio: 'ignore', shell: true });
};

const menu = `
Ignite Zero Factory Launcher
============================
1) Start Factory (npm run dev:up)
2) Run System Check (npm run verify)
3) Exit
Select an option: `;

const prompt = () =>
  rl.question(menu, async (answer) => {
    if (answer.trim() === '1') {
      console.log('\nStarting dev server... press Ctrl+C to stop.\n');
      try {
        openBrowser('http://localhost:5173/architect');
        await runCommand('npm', ['run', 'dev:up']);
      } catch (err: any) {
        console.error(err.message || err);
      } finally {
        prompt();
      }
    } else if (answer.trim() === '2') {
      console.log('\nRunning verification suite...\n');
      try {
        await runCommand('npm', ['run', 'verify']);
        console.log('\n✅ Factory check complete.\n');
      } catch (err: any) {
        console.error('\n❌ Verification failed:', err.message || err);
      } finally {
        prompt();
      }
    } else if (answer.trim() === '3') {
      console.log('Goodbye!');
      rl.close();
    } else {
      console.log('\nUnknown option. Please pick 1-3.\n');
      prompt();
    }
  });

console.clear();
prompt();

