// Pipeline smoke: health -> (optional) enqueueAndTrack -> listJobs -> (optional) getCourse
// Writes outputs to reports/ and artifacts/

import fs from 'node:fs';
import path from 'node:path';

const BASE_URL = process.env.MCP_BASE_URL || 'http://127.0.0.1:4000';
const TOKEN = process.env.MCP_AUTH_TOKEN || 'dev-local-secret';
const COURSE_ID = process.env.COURSE_ID || '';

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

async function call(method, params = {}) {
  const res = await fetch(BASE_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ method, params }),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status} ${text}`);
  try { return JSON.parse(text); } catch { return text; }
}

(async () => {
  ensureDir('reports');
  ensureDir('artifacts');

  const outputs = { steps: [] };

  // 1) Health
  const health = await call('lms.health', {});
  outputs.steps.push({ name: 'health', ok: health?.ok === true, data: health });

  // 2) Optionally enqueue a tiny job if COURSE_ID supplied
  let tracked = null;
  if (COURSE_ID) {
    const params = {
      jobType: 'variants',
      courseId: COURSE_ID,
      itemRef: { itemId: 1 },
      payload: { operation: 'rewrite', text: 'smoke' },
      pollMs: 750,
      timeoutMs: 20000
    };
    tracked = await call('lms.enqueueAndTrack', params);
    outputs.steps.push({ name: 'enqueueAndTrack', ok: true, data: tracked });
  } else {
    outputs.steps.push({ name: 'enqueueAndTrack', ok: true, skipped: true, reason: 'COURSE_ID not set' });
  }

  // 3) listJobs
  const jobs = await call('lms.listJobs', {});
  outputs.steps.push({ name: 'listJobs', ok: Array.isArray(jobs) || !!jobs?.data, count: Array.isArray(jobs) ? jobs.length : (jobs?.data?.length ?? 0) });

  // 4) Optionally fetch course
  if (COURSE_ID) {
    const course = await call('lms.getCourse', { courseId: COURSE_ID });
    outputs.steps.push({ name: 'getCourse', ok: !!course && typeof course === 'object', keys: Object.keys(course || {}) });
  } else {
    outputs.steps.push({ name: 'getCourse', ok: true, skipped: true, reason: 'COURSE_ID not set' });
  }

  fs.writeFileSync(path.join('reports', 'pipeline-smoke.json'), JSON.stringify(outputs, null, 2));
  fs.writeFileSync(path.join('artifacts', 'pipeline-smoke-artifacts.json'), JSON.stringify(outputs, null, 2));

  const allOk = outputs.steps.every(s => s.ok);
  if (!allOk) {
    console.error('[PIPELINE SMOKE] FAILED', outputs);
    process.exit(1);
  }
  console.log('[PIPELINE SMOKE] OK');
})().catch((e) => {
  console.error('[PIPELINE SMOKE] FAILED:', e.message);
  process.exit(1);
});


