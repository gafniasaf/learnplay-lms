This file exists solely to force a fresh sync of the Ignite Zero seed to Lovable Dev.


