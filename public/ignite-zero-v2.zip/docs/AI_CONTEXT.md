# 🧠 IGNITE ZERO: SYSTEM CONTEXT & INVARIANTS

> CRITICAL INSTRUCTION FOR AI AGENTS:
> You are operating within the Ignite Zero architecture.
> Standard "Best Practices" for generic React/Node apps often VIOLATE our constraints.
> Follow these rules or the system will break.

## 🚫 NEGATIVE CONSTRAINTS (WHAT WE ARE NOT)

1.  No Generic MCP: We do NOT use `@modelcontextprotocol/server-supabase` or `npx` connectors. We use a Custom Local MCP Server located in `./lms-mcp`.
2.  No Cloud Dependency: We do NOT develop against `supabase.co` directly. We develop against `127.0.0.1:54321` (Docker).
3.  No Inline Logic: We do NOT write business logic in `ai-job-runner/index.ts`. We use the Strategy Pattern in `strategies/`.
4.  No Hardcoded UI: We do NOT write `<Button>` for actions in Editors. We update `system-manifest.json` -> `agent_jobs` -> `ui`.
5.  No Manual Forms: We do NOT write `<Input>` tags. We use the generic `<ManifestForm />` or `<ManifestField />`.

## 🏗️ SYSTEM ARCHITECTURE

### 1. The Control Plane (MCP)

- Location: `./lms-mcp` (Custom Node.js Server).
- Protocol: SSE via `http://localhost:4000/sse`.
- Role: Handles Validation and Job Enqueuing only. It does NOT execute business logic.
- Network: Uses `http://host.docker.internal:4000` to bridge Supabase Docker to Host.

### 2. The Execution Plane (Edge)

- Location: `supabase/functions/ai-job-runner`.
- Role: Executes the Strategy Pattern.
- Registry: `registry.ts` maps Job IDs to Strategy Files.
- Strategies: Locate in `strategies/`. Can be manual (`task-expander.ts`) or generated (`gen-compile_brief.ts`).

### 3. The Definition Plane (Manifest)

- File: `system-manifest.json`.
- Role: The Single Source of Truth for Data Models, UI Actions, and Job Configs.
- Change Protocol: Update Manifest -> Run `npm run scaffold` -> Verify.

## 🔄 THE BUILDER LOOP (HOW TO WORK)

If you are asked to build a feature:

1.  Check `system-manifest.json`.
2.  Scaffold: Run `npx tsx scripts/scaffold-manifest.ts`.
3.  Implement: Write the Strategy in `supabase/functions/ai-job-runner/strategies/...`.
4.  Verify: Run `npm run verify`.


