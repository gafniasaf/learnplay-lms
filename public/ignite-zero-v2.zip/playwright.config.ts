import type { PlaywrightTestConfig } from '@playwright/test';

const PORT = process.env.PORT ? Number(process.env.PORT) : 8080;

const config: PlaywrightTestConfig = {
  testDir: '.',
  testMatch: ['tests/e2e/**/*.spec.ts', 'src/e2e/**/*.spec.ts'],
  timeout: 60_000, // Increased to 60s for slow pages
  retries: process.env.CI ? 2 : 1, // Retry once for flaky tests
  reporter: [['list'], ['junit', { outputFile: 'reports/playwright-junit.xml' }], ['html', { outputFolder: 'reports/playwright-html', open: 'never' }]],
  use: {
    baseURL: `http://localhost:${PORT}`,
    headless: true,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
    actionTimeout: 10_000, // Wait up to 10s for actions
  },
  webServer: {
    command: 'npm run build && npm run preview',
    port: PORT,
    reuseExistingServer: !process.env.CI,
    timeout: 120_000, // 2 minutes for build + preview startup
    env: {
      // Force mock mode for deterministic E2E
      VITE_USE_MOCK: 'true',
      SKIP_VERIFY: '1',
      VITE_BYPASS_AUTH: 'true',
    },
  },
  // Global setup - ensure clean state
  globalSetup: undefined,
};

export default config;


