import http from "node:http";
import { URL } from "node:url";
import { config } from "./config.js";
import { callJson } from "./http.js";

const METHODS = ["lms.health", "lms.enqueueJob", "lms.listJobs", "lms.getJob"] as const;

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url) {
    const url = new URL(req.url, `http://${config.host}:${config.port}`);
    if (url.pathname === "/health") {
      return send(res, 200, { ok: true, methods: METHODS });
    }
  }

  if (req.method !== "POST") {
    return send(res, 405, { ok: false, error: "Method Not Allowed" });
  }

  const authHeader = req.headers["authorization"] || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (token !== config.mcpAuthToken) {
    return send(res, 401, { ok: false, error: "Unauthorized" });
  }

  try {
    const body = await readBody(req);
    const { method, params = {} } = body ?? {};
    if (!method || typeof method !== "string") {
      return send(res, 400, { ok: false, error: "method is required" });
    }

    switch (method) {
      case "lms.health": {
        return send(res, 200, { ok: true, methods: METHODS });
      }
      case "lms.enqueueJob": {
        const result = await enqueueJob(params);
        return send(res, 200, { ok: true, result });
      }
      case "lms.listJobs": {
        const result = await listJobs(params);
        return send(res, 200, { ok: true, result });
      }
      case "lms.getJob": {
        const result = await getJob(params);
        return send(res, 200, { ok: true, result });
      }
      default:
        return send(res, 404, { ok: false, error: `Unknown method: ${method}` });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return send(res, 500, { ok: false, error: message });
  }
});

server.listen(config.port, config.host, () => {
  console.log(`MCP server listening on http://${config.host}:${config.port}`);
});

async function enqueueJob(params: any) {
  const jobType = params?.jobType;
  if (!jobType || typeof jobType !== "string") {
    throw new Error("jobType is required");
  }
  const payload = (params?.payload && typeof params.payload === "object") ? params.payload : {};
  return supabaseFetch("enqueue-job", {
    method: "POST",
    headers: { "X-Agent-Token": config.agentToken },
    body: { jobType, payload },
  });
}

async function listJobs(params: any) {
  const limit = Math.min(100, Math.max(1, Number(params?.limit || 20)));
  // Ensure we are hitting the correct edge function path
  return supabaseFetch("list-jobs", { 
    method: "GET",
    // Pass limit as query param if needed, but supabaseFetch handles path construction
  });
}

async function getJob(params: any) {
  const id = params?.id;
  if (!id || typeof id !== "string") {
    throw new Error("id is required");
  }
  return supabaseFetch(`get-job?id=${encodeURIComponent(id)}`, { method: "GET" });
}

function supabaseFetch(path: string, opts: { method?: "GET" | "POST"; headers?: Record<string, string>; body?: unknown } = {}) {
  // Clean up path to avoid double slashes or missing query params
  const normalizedPath = path.startsWith("/") ? path.slice(1) : path;
  const url = `${config.supabaseUrl}/functions/v1/${normalizedPath}`;
  const headers = {
    apikey: config.supabaseAnonKey,
    ...(opts.headers || {}),
  };
  return callJson(url, { method: opts.method, headers, body: opts.body });
}

function readBody(req: http.IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
    });
    req.on("end", () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(err);
      }
    });
    req.on("error", reject);
  });
}

function send(res: http.ServerResponse, status: number, body: Record<string, unknown>) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}
